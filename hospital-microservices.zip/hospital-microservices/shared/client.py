"""How one microservice calls another.

The gateway registers every service app in `apps`; a call goes straight into the other
service's app (no ports), and the other service's errors come back as our own exceptions.
"""
import anyio.from_thread
import httpx

from shared.config import settings
from shared.exceptions import ERROR_BY_STATUS, ServiceUnavailableError

apps: dict = {}  # service name -> FastAPI app, filled in by gateway/main.py


def call(service: str, method: str, path: str, json=None, params=None):
    async def send():
        transport = httpx.ASGITransport(app=apps[service], raise_app_exceptions=False)
        async with httpx.AsyncClient(transport=transport, base_url="http://service") as client:
            return await client.request(method, path, json=json, params=params,
                                        headers={"x-internal-key": settings.INTERNAL_API_KEY})

    response = anyio.from_thread.run(send)  # our endpoints are plain `def`, so we run in a worker thread
    if response.status_code >= 400:
        detail = response.json().get("detail") if response.content else None
        raise ERROR_BY_STATUS.get(response.status_code, ServiceUnavailableError)(
            detail if isinstance(detail, str) else None)
    return response.json() if response.content else None
