"""Audit trail: who did what, and when.

The rows live in the auth service (table `audit_logs`). Every other service calls `record(...)` after an
action succeeded; it is best effort, so a problem with the audit trail never breaks the real action.
(The auth service writes its own rows straight through its repository.)
"""
import logging
from typing import Optional

from shared.client import call
from shared.dependencies import CurrentUser

logger = logging.getLogger("audit")


def record(user: Optional[CurrentUser], action: str, entity: Optional[str] = None,
           entity_id: Optional[int] = None, detail: Optional[str] = None) -> None:
    entry = {"user_id": user.id if user else None, "action": action, "entity": entity,
             "entity_id": entity_id, "detail": detail}
    logger.info("AUDIT %s", entry)
    try:
        call("auth", "POST", "/internal/audit", json=entry)
    except Exception:
        logger.exception("Could not store audit entry %s", entry)
