"""A tiny in-memory rate limiter (used for failed logins).

It lives in the memory of this one process, which fits the single-uvicorn setup. If you ever run several
workers, move the counters to Redis.
"""
import time
from typing import Optional
from collections import deque
from threading import Lock

from shared.config import settings
from shared.exceptions import TooManyRequestsError


class RateLimiter:
    def __init__(self, max_attempts: int, window_seconds: int):
        self.max_attempts = max_attempts
        self.window = window_seconds
        self._hits: dict[str, deque] = {}
        self._lock = Lock()

    def _recent(self, key: str) -> deque:
        hits = self._hits.get(key)
        if hits is None:
            return deque()
        while hits and hits[0] <= time.monotonic() - self.window:
            hits.popleft()
        if not hits:
            del self._hits[key]  # keeps the dict from growing forever
        return hits

    def check(self, key: str) -> None:
        """Raise 429 if `key` already used up its attempts."""
        with self._lock:
            hits = self._recent(key)
            if len(hits) >= self.max_attempts:
                wait = int(hits[0] + self.window - time.monotonic()) + 1
                raise TooManyRequestsError(f"Too many failed attempts. Try again in {wait} seconds")

    def hit(self, key: str) -> None:
        with self._lock:
            self._recent(key)
            self._hits.setdefault(key, deque()).append(time.monotonic())

    def reset(self, key: Optional[str] = None) -> None:
        """Forget one key (after a successful login) or everything."""
        with self._lock:
            if key is None:
                self._hits.clear()
            else:
                self._hits.pop(key, None)


login_limiter = RateLimiter(settings.LOGIN_MAX_ATTEMPTS, settings.LOGIN_WINDOW_SECONDS)
