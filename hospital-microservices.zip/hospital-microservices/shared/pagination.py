from typing import Generic, Literal, Optional, TypeVar

from pydantic import BaseModel
from sqlalchemy import func, select

T = TypeVar("T")

SortOrder = Literal["asc", "desc"]  # the `order` query parameter


class Page(BaseModel, Generic[T]):
    items: list[T]
    total: int
    page: int
    size: int


def paginate(db, query, page: int, size: int) -> dict:
    total = db.scalar(select(func.count()).select_from(query.order_by(None).subquery()))
    items = db.scalars(query.offset((page - 1) * size).limit(size)).all()
    return {"items": items, "total": total, "page": page, "size": size}


def sort_clauses(columns: dict, sort_by: Optional[str], order: Optional[SortOrder],
                 default_sort: str, default_order: SortOrder = "asc") -> list:
    """ORDER BY for the `sort_by` / `order` query parameters.

    `columns` maps each allowed sort name to the column(s) to sort by (extra columns are tie-breakers),
    so a client can only sort by what the endpoint allows.
    """
    wanted = columns[sort_by if sort_by in columns else default_sort]
    wanted = wanted if isinstance(wanted, (list, tuple)) else [wanted]
    descending = (order or default_order) == "desc"
    return [column.desc() if descending else column.asc() for column in wanted]
