"""Who is calling? The gateway checks the JWT and passes the result in two headers.

/internal/* endpoints (service to service) additionally require the secret `x-internal-key` header.
"""
import hmac
from dataclasses import dataclass

from fastapi import Depends, Request

from shared.config import settings
from shared.exceptions import ForbiddenError, UnauthorizedError


@dataclass
class CurrentUser:
    id: int
    role: str


def get_current_user(request: Request) -> CurrentUser:
    user_id = request.headers.get("x-user-id")
    role = request.headers.get("x-user-role")
    if not user_id or not role:
        raise UnauthorizedError()
    return CurrentUser(id=int(user_id), role=role)


def require_role(*roles):
    def checker(user: CurrentUser = Depends(get_current_user)) -> CurrentUser:
        if user.role not in roles:
            raise ForbiddenError()
        return user

    return checker


def require_internal_key(request: Request) -> None:
    """Put on every /internal router: only callers that know INTERNAL_API_KEY get in."""
    key = request.headers.get("x-internal-key", "")
    if not hmac.compare_digest(key.encode(), settings.INTERNAL_API_KEY.encode()):
        raise ForbiddenError("Invalid internal key")
