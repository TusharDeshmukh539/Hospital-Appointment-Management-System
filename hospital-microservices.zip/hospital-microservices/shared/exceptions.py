from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from sqlalchemy.exc import IntegrityError


class AppError(Exception):
    status_code = 400
    default_detail = "Bad request"

    def __init__(self, detail: str | None = None):
        self.detail = detail or self.default_detail


class BadRequestError(AppError):
    status_code = 400


class UnauthorizedError(AppError):
    status_code = 401
    default_detail = "Not authenticated"


class ForbiddenError(AppError):
    status_code = 403
    default_detail = "You do not have permission to perform this action"


class NotFoundError(AppError):
    status_code = 404
    default_detail = "Resource not found"


class ConflictError(AppError):
    status_code = 409
    default_detail = "Conflict with existing data"


class TooManyRequestsError(AppError):
    status_code = 429
    default_detail = "Too many requests, please try again later"


class ServiceUnavailableError(AppError):
    status_code = 503
    default_detail = "A required service is unavailable"


ERROR_BY_STATUS = {400: BadRequestError, 401: UnauthorizedError, 403: ForbiddenError,
                   404: NotFoundError, 409: ConflictError, 429: TooManyRequestsError}


def add_error_handlers(app: FastAPI) -> None:
    """Every service and the gateway answer errors as {"detail": "..."}."""

    @app.exception_handler(AppError)
    async def app_error(request: Request, exc: AppError):
        headers = {"WWW-Authenticate": "Bearer"} if exc.status_code == 401 else None
        return JSONResponse({"detail": exc.detail}, status_code=exc.status_code, headers=headers)

    @app.exception_handler(IntegrityError)
    async def integrity_error(request: Request, exc: IntegrityError):
        return JSONResponse({"detail": "The request conflicts with existing data"}, status_code=409)
