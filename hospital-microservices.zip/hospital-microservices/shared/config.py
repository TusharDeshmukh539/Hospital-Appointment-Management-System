from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # one database per microservice
    AUTH_DATABASE_URL: str
    DOCTOR_DATABASE_URL: str
    PATIENT_DATABASE_URL: str
    SCHEDULE_DATABASE_URL: str
    APPOINTMENT_DATABASE_URL: str

    JWT_SECRET_KEY: str
    INTERNAL_API_KEY: str  # shared secret for service-to-service (/internal) calls
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    BCRYPT_ROUNDS: int = 12
    CORS_ORIGINS: str = "http://localhost:3000"
    CANCELLATION_CUTOFF_HOURS: int = 2
    LOGIN_MAX_ATTEMPTS: int = 5  # failed logins allowed per email ...
    LOGIN_WINDOW_SECONDS: int = 300  # ... within this many seconds


settings = Settings()
