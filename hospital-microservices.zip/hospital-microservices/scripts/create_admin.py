"""Create the first ADMIN account (there is no public endpoint for admins).

Run once after the auth migrations:  python -m scripts.create_admin admin@example.com 'Admin123!' "Admin User"
"""
import sys

from services.auth_service.app import models  # noqa: F401
from services.auth_service.app.database import SessionLocal
from services.auth_service.app.repositories import user_repo
from shared.enums import Role
from shared.security import hash_password

if len(sys.argv) != 4:
    sys.exit(__doc__)
email, password, full_name = sys.argv[1:]
with SessionLocal() as db:
    if user_repo.get_by_email(db, email):
        sys.exit(f"{email} already exists")
    user = user_repo.create(db, email, hash_password(password), full_name, None, Role.ADMIN.value)
    db.commit()
    print(f"Created admin #{user.id} ({user.email})")
