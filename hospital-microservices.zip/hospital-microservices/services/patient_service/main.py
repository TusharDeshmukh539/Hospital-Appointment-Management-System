"""Patient service: patient profiles. Database: PATIENT_DATABASE_URL (table: patients)."""
from fastapi import FastAPI

from services.patient_service.app import models  # noqa: F401
from services.patient_service.app.routes import internal, patients
from shared.exceptions import add_error_handlers

app = FastAPI(title="Patient service", docs_url=None, redoc_url=None, openapi_url=None)
add_error_handlers(app)
app.include_router(patients.router)
app.include_router(internal.router)
