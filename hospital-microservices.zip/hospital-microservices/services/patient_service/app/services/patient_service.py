from sqlalchemy.orm import Session

from services.patient_service.app.repositories import patient_repo
from services.patient_service.app.schemas.patient import PatientInternalCreate, PatientUpdate
from shared import audit
from shared.client import call
from shared.dependencies import CurrentUser
from shared.exceptions import ConflictError, NotFoundError


def get_my_profile(db: Session, user: CurrentUser):
    """Story 11."""
    patient = patient_repo.get_by_user_id(db, user.id)
    if patient is None:
        raise NotFoundError("Patient profile not found")
    return patient


def update_my_profile(db: Session, user: CurrentUser, data: PatientUpdate):
    """Story 12. Name and phone belong to the account, so the auth service is updated too."""
    patient = get_my_profile(db, user)
    changes = data.model_dump(exclude_unset=True)
    for field, value in changes.items():
        setattr(patient, field, value)
    db.flush()
    account_changes = {k: v for k, v in changes.items() if k in ("full_name", "phone")}
    if account_changes:
        try:
            call("auth", "PATCH", f"/internal/users/{user.id}", json=account_changes)
        except Exception:
            db.rollback()
            raise
    db.commit()
    audit.record(user, "PATIENT_PROFILE_UPDATED", "patient", patient.id, ", ".join(sorted(changes)))
    return patient


def list_patients(db: Session, text, sort_by: str, order, page: int, size: int) -> dict:
    """Admin patient list."""
    return patient_repo.search(db, text, sort_by, order, page, size)


# ---- used by the other services ----

def create_patient(db: Session, data: PatientInternalCreate):
    if patient_repo.get_by_user_id(db, data.user_id):
        raise ConflictError("A patient profile already exists for this user")
    patient = patient_repo.create(db, data.user_id, data.full_name, data.email, data.phone)
    db.commit()
    return patient


def get_patient_by_user(db: Session, user_id: int):
    patient = patient_repo.get_by_user_id(db, user_id)
    if patient is None:
        raise NotFoundError("Patient profile not found")
    return patient
