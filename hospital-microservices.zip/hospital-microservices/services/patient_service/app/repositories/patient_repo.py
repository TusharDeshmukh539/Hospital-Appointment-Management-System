from typing import Optional

from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from services.patient_service.app.models.patient import Patient
from shared.pagination import paginate, sort_clauses

SORTABLE = {"full_name": [Patient.full_name, Patient.id], "email": [Patient.email, Patient.id],
            "created_at": [Patient.created_at, Patient.id], "id": [Patient.id]}


def get_by_user_id(db: Session, user_id: int) -> Optional[Patient]:
    return db.scalar(select(Patient).where(Patient.user_id == user_id))


def create(db: Session, user_id: int, full_name: str, email: str, phone: Optional[str]) -> Patient:
    patient = Patient(user_id=user_id, full_name=full_name, email=email.lower(), phone=phone)
    db.add(patient)
    db.flush()
    return patient


def search(db: Session, text: Optional[str], sort_by: str, order: Optional[str], page: int, size: int) -> dict:
    """All patients; `text` matches the name or the email (contains, any case)."""
    query = select(Patient)
    if text:
        like = f"%{text.lower()}%"
        query = query.where(or_(func.lower(Patient.full_name).like(like), func.lower(Patient.email).like(like)))
    return paginate(db, query.order_by(*sort_clauses(SORTABLE, sort_by, order, "full_name")), page, size)
