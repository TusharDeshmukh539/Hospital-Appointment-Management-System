from typing import Literal, Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from services.patient_service.app.database import get_db
from services.patient_service.app.schemas.patient import PatientOut, PatientUpdate
from services.patient_service.app.services import patient_service
from shared.dependencies import CurrentUser, require_role
from shared.enums import Role
from shared.pagination import Page, SortOrder

router = APIRouter(prefix="/patients", tags=["Patients"])
patient_only = require_role(Role.PATIENT)


@router.get("", response_model=Page[PatientOut], summary="List all patients (ADMIN)")
def list_patients(q: Optional[str] = Query(None, max_length=100, description="Part of the name or email"),
                  sort_by: Literal["full_name", "email", "created_at", "id"] = "full_name",
                  order: Optional[SortOrder] = Query(None, description="asc (default) or desc"),
                  page: int = Query(1, ge=1), size: int = Query(10, ge=1, le=100),
                  db: Session = Depends(get_db), _=Depends(require_role(Role.ADMIN))):
    return patient_service.list_patients(db, q, sort_by, order, page, size)


@router.get("/me", response_model=PatientOut, summary="My patient profile (PATIENT)")
def get_my_profile(db: Session = Depends(get_db), user: CurrentUser = Depends(patient_only)):
    return patient_service.get_my_profile(db, user)


@router.put("/me", response_model=PatientOut, summary="Update my patient profile (PATIENT)")
def update_my_profile(data: PatientUpdate, db: Session = Depends(get_db),
                      user: CurrentUser = Depends(patient_only)):
    return patient_service.update_my_profile(db, user, data)
