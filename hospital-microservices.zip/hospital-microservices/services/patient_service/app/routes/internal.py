"""Called by the other services only (the gateway does not route /internal)."""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from services.patient_service.app.database import get_db
from services.patient_service.app.schemas.patient import PatientInternalCreate, PatientInternalOut
from services.patient_service.app.services import patient_service
from shared.dependencies import require_internal_key

router = APIRouter(prefix="/internal/patients", include_in_schema=False, dependencies=[Depends(require_internal_key)])


@router.post("", response_model=PatientInternalOut, status_code=201)
def create_patient(data: PatientInternalCreate, db: Session = Depends(get_db)):
    return patient_service.create_patient(db, data)


@router.get("/by-user/{user_id}", response_model=PatientInternalOut)
def patient_by_user(user_id: int, db: Session = Depends(get_db)):
    return patient_service.get_patient_by_user(db, user_id)
