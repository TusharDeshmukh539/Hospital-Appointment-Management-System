from datetime import date, datetime
from typing import Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


class PatientUpdate(BaseModel):
    full_name: Optional[str] = Field(default=None, min_length=2, max_length=100)
    phone: Optional[str] = Field(default=None, pattern=r"^\+?[0-9]{10,13}$")
    date_of_birth: Optional[date] = None
    gender: Optional[Literal["MALE", "FEMALE", "OTHER"]] = None
    blood_group: Optional[str] = Field(default=None, pattern=r"^(A|B|AB|O)[+-]$")
    address: Optional[str] = Field(default=None, max_length=255)

    @field_validator("date_of_birth")
    @classmethod
    def past_date(cls, value: Optional[date]) -> Optional[date]:
        if value is not None and (value > date.today() or value.year < 1900):
            raise ValueError("date_of_birth must be a past date after 1900")
        return value


class PatientOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    full_name: str
    email: str
    phone: Optional[str]
    date_of_birth: Optional[date]
    gender: Optional[str]
    blood_group: Optional[str]
    address: Optional[str]
    created_at: datetime
    updated_at: datetime


# Used only by other services (internal API)
class PatientInternalCreate(BaseModel):
    user_id: int
    full_name: str
    email: str
    phone: Optional[str] = None


class PatientInternalOut(PatientOut):
    user_id: int
