from services.patient_service.app.models.patient import Patient

__all__ = ["Patient"]
