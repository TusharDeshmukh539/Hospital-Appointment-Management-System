from sqlalchemy.orm import Session

from services.doctor_service.app.repositories import speciality_repo
from services.doctor_service.app.schemas.speciality import SpecialityIn
from shared import audit
from shared.dependencies import CurrentUser
from shared.exceptions import ConflictError, NotFoundError


def create_speciality(db: Session, admin: CurrentUser, data: SpecialityIn):
    if speciality_repo.get_by_name(db, data.name):
        raise ConflictError("This speciality already exists")
    speciality = speciality_repo.create(db, data.name)
    db.commit()
    audit.record(admin, "SPECIALITY_CREATED", "speciality", speciality.id, speciality.name)
    return speciality


def list_specialities(db: Session, sort_by: str, order, page: int, size: int) -> dict:
    return speciality_repo.list_all(db, sort_by, order, page, size)


def update_speciality(db: Session, admin: CurrentUser, speciality_id: int, data: SpecialityIn):
    speciality = speciality_repo.get_by_id(db, speciality_id)
    if speciality is None:
        raise NotFoundError("Speciality not found")
    other = speciality_repo.get_by_name(db, data.name)
    if other is not None and other.id != speciality.id:
        raise ConflictError("This speciality already exists")
    speciality.name = data.name
    db.commit()
    audit.record(admin, "SPECIALITY_UPDATED", "speciality", speciality.id, speciality.name)
    return speciality


def delete_speciality(db: Session, admin: CurrentUser, speciality_id: int) -> None:
    speciality = speciality_repo.get_by_id(db, speciality_id)
    if speciality is None:
        raise NotFoundError("Speciality not found")
    if speciality_repo.count_doctors(db, speciality_id) > 0:
        raise ConflictError("Speciality is used by doctors and cannot be deleted")
    name = speciality.name
    speciality_repo.delete(db, speciality)
    db.commit()
    audit.record(admin, "SPECIALITY_DELETED", "speciality", speciality_id, name)
