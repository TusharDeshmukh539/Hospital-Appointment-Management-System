from typing import Optional

from sqlalchemy.orm import Session

from services.doctor_service.app.repositories import doctor_repo, speciality_repo
from services.doctor_service.app.schemas.doctor import DoctorCreate, DoctorUpdate
from shared import audit
from shared.client import call
from shared.dependencies import CurrentUser
from shared.enums import Role
from shared.exceptions import ConflictError, NotFoundError


def create_doctor(db: Session, admin: CurrentUser, data: DoctorCreate):
    """Story 2: the login account is created in the auth service, the profile here."""
    if speciality_repo.get_by_id(db, data.speciality_id) is None:
        raise NotFoundError("Speciality not found")
    if doctor_repo.get_by_registration_no(db, data.registration_no):
        raise ConflictError("A doctor with this registration number already exists")

    user = call("auth", "POST", "/internal/users", json={
        "email": data.email, "password": data.password, "full_name": data.full_name,
        "phone": data.phone, "role": Role.DOCTOR.value})  # 409 if the email is taken
    try:
        doctor = doctor_repo.create(
            db, user_id=user["id"], full_name=user["full_name"], speciality_id=data.speciality_id,
            registration_no=data.registration_no, qualification=data.qualification,
            experience_years=data.experience_years, consultation_fee=data.consultation_fee)
        db.commit()
    except Exception:  # undo the account if the profile could not be saved
        db.rollback()
        call("auth", "DELETE", f"/internal/users/{user['id']}")
        raise
    audit.record(admin, "DOCTOR_CREATED", "doctor", doctor.id)
    return doctor_repo.get_by_id(db, doctor.id)


def get_my_profile(db: Session, user: CurrentUser):
    doctor = doctor_repo.get_by_user_id(db, user.id)
    if doctor is None:
        raise NotFoundError("Doctor profile not found")
    return doctor


def update_my_profile(db: Session, user: CurrentUser, data: DoctorUpdate):
    """Story 6."""
    doctor = get_my_profile(db, user)
    changes = data.model_dump(exclude_unset=True, exclude_none=True)
    if "speciality_id" in changes and speciality_repo.get_by_id(db, changes["speciality_id"]) is None:
        raise NotFoundError("Speciality not found")
    for field, value in changes.items():
        setattr(doctor, field, value)
    db.commit()
    audit.record(user, "DOCTOR_PROFILE_UPDATED", "doctor", doctor.id, ", ".join(sorted(changes)))
    return doctor_repo.get_by_id(db, doctor.id)


def search_doctors(db: Session, speciality: Optional[str], name: Optional[str], sort_by: str,
                   order: Optional[str], page: int, size: int) -> dict:
    """Story 9."""
    return doctor_repo.search(db, speciality, name, sort_by, order, page, size)


def view_doctor(db: Session, user: CurrentUser, doctor_id: int):
    """One doctor's profile. A deactivated doctor is hidden (404) from everybody except admins."""
    doctor = get_doctor(db, doctor_id)
    if not doctor.is_active and user.role != Role.ADMIN.value:
        raise NotFoundError("Doctor not found")
    return doctor


# ---- used by the other services ----

def get_doctor(db: Session, doctor_id: int):
    doctor = doctor_repo.get_by_id(db, doctor_id)
    if doctor is None:
        raise NotFoundError("Doctor not found")
    return doctor


def get_doctor_by_user(db: Session, user_id: int):
    doctor = doctor_repo.get_by_user_id(db, user_id)
    if doctor is None:
        raise NotFoundError("Doctor profile not found")
    return doctor


def set_active(db: Session, user_id: int, is_active: bool):
    doctor = get_doctor_by_user(db, user_id)
    doctor.is_active = is_active
    db.commit()
    return doctor
