from services.doctor_service.app.models.doctor import Doctor
from services.doctor_service.app.models.speciality import Speciality

__all__ = ["Doctor", "Speciality"]
