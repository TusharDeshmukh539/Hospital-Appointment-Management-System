from decimal import Decimal

from sqlalchemy import Boolean, ForeignKey, Integer, Numeric, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from services.doctor_service.app.database import Base
from shared.models import TimestampMixin


class Doctor(Base, TimestampMixin):
    __tablename__ = "doctors"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(Integer, unique=True)  # account id in the auth service
    speciality_id: Mapped[int] = mapped_column(ForeignKey("specialities.id"))
    registration_no: Mapped[str] = mapped_column(String(50), unique=True)
    qualification: Mapped[str] = mapped_column(String(200))
    experience_years: Mapped[int] = mapped_column(Integer)
    consultation_fee: Mapped[Decimal] = mapped_column(Numeric(12, 2))
    # copies of the account data, so doctors can be searched by name and hidden when deactivated
    full_name: Mapped[str] = mapped_column(String(100))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

    speciality = relationship("Speciality")

    @property
    def speciality_name(self) -> str:
        return self.speciality.name
