from sqlalchemy import String
from sqlalchemy.orm import Mapped, mapped_column

from services.doctor_service.app.database import Base
from shared.models import TimestampMixin


class Speciality(Base, TimestampMixin):
    __tablename__ = "specialities"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(100), unique=True)
