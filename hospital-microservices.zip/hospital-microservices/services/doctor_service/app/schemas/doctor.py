from datetime import datetime
from decimal import Decimal
from typing import Optional

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator

from shared.security import check_password_strength


class DoctorCreate(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)
    full_name: str = Field(min_length=2, max_length=100)
    phone: Optional[str] = Field(default=None, pattern=r"^\+?[0-9]{10,13}$")
    speciality_id: int = Field(gt=0)
    registration_no: str = Field(min_length=3, max_length=50)
    qualification: str = Field(min_length=2, max_length=200)
    experience_years: int = Field(ge=0, le=70)
    consultation_fee: Decimal = Field(ge=0, max_digits=12, decimal_places=2)

    @field_validator("email")
    @classmethod
    def lowercase_email(cls, value: str) -> str:
        return value.lower()

    @field_validator("password")
    @classmethod
    def strong_password(cls, value: str) -> str:
        return check_password_strength(value)


class DoctorUpdate(BaseModel):
    speciality_id: Optional[int] = Field(default=None, gt=0)
    qualification: Optional[str] = Field(default=None, min_length=2, max_length=200)
    experience_years: Optional[int] = Field(default=None, ge=0, le=70)
    consultation_fee: Optional[Decimal] = Field(default=None, ge=0, max_digits=12, decimal_places=2)


class DoctorOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    full_name: str
    speciality_id: int
    speciality_name: str
    registration_no: str
    qualification: str
    experience_years: int
    consultation_fee: Decimal
    created_at: datetime
    updated_at: datetime


# Used only by other services (internal API)
class DoctorInternalOut(DoctorOut):
    user_id: int
    is_active: bool


class ActiveFlag(BaseModel):
    is_active: bool
