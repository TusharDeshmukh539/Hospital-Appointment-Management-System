from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class SpecialityIn(BaseModel):
    name: str = Field(min_length=2, max_length=100)


class SpecialityOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    created_at: datetime
    updated_at: datetime
