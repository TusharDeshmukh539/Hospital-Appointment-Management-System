from typing import Literal, Optional

from fastapi import APIRouter, Depends, Query, Response
from sqlalchemy.orm import Session

from services.doctor_service.app.database import get_db
from services.doctor_service.app.schemas.speciality import SpecialityIn, SpecialityOut
from services.doctor_service.app.services import speciality_service
from shared.dependencies import get_current_user, require_role
from shared.enums import Role
from shared.pagination import Page, SortOrder

router = APIRouter(prefix="/specialities", tags=["Specialities"])
admin_only = require_role(Role.ADMIN)


@router.post("", response_model=SpecialityOut, status_code=201, summary="Create a speciality (ADMIN)")
def create_speciality(data: SpecialityIn, db: Session = Depends(get_db), admin=Depends(admin_only)):
    return speciality_service.create_speciality(db, admin, data)


@router.get("", response_model=Page[SpecialityOut], summary="List specialities")
def list_specialities(sort_by: Literal["name", "id"] = "name", order: Optional[SortOrder] = Query(None),
                      page: int = Query(1, ge=1), size: int = Query(10, ge=1, le=100),
                      db: Session = Depends(get_db), _=Depends(get_current_user)):
    return speciality_service.list_specialities(db, sort_by, order, page, size)


@router.put("/{speciality_id}", response_model=SpecialityOut, summary="Rename a speciality (ADMIN)")
def update_speciality(speciality_id: int, data: SpecialityIn, db: Session = Depends(get_db),
                      admin=Depends(admin_only)):
    return speciality_service.update_speciality(db, admin, speciality_id, data)


@router.delete("/{speciality_id}", status_code=204, summary="Delete an unused speciality (ADMIN)")
def delete_speciality(speciality_id: int, db: Session = Depends(get_db), admin=Depends(admin_only)):
    speciality_service.delete_speciality(db, admin, speciality_id)
    return Response(status_code=204)
