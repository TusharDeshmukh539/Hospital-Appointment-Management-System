from typing import Literal, Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from services.doctor_service.app.database import get_db
from services.doctor_service.app.schemas.doctor import DoctorCreate, DoctorOut, DoctorUpdate
from services.doctor_service.app.services import doctor_service
from shared.dependencies import CurrentUser, get_current_user, require_role
from shared.enums import Role
from shared.pagination import Page, SortOrder

router = APIRouter(prefix="/doctors", tags=["Doctors"])


@router.post("", response_model=DoctorOut, status_code=201, summary="Create a doctor account (ADMIN)")
def create_doctor(data: DoctorCreate, db: Session = Depends(get_db),
                  admin: CurrentUser = Depends(require_role(Role.ADMIN))):
    return doctor_service.create_doctor(db, admin, data)


@router.get("", response_model=Page[DoctorOut], summary="Search doctors by speciality and name")
def search_doctors(speciality: Optional[str] = Query(None, max_length=100),
                   name: Optional[str] = Query(None, max_length=100),
                   sort_by: Literal["full_name", "experience_years", "consultation_fee"] = "full_name",
                   order: Optional[SortOrder] = Query(None, description="asc (default) or desc"),
                   page: int = Query(1, ge=1), size: int = Query(10, ge=1, le=100),
                   db: Session = Depends(get_db), _=Depends(get_current_user)):
    return doctor_service.search_doctors(db, speciality, name, sort_by, order, page, size)


@router.get("/me", response_model=DoctorOut, summary="My doctor profile (DOCTOR)")
def get_my_profile(db: Session = Depends(get_db), user: CurrentUser = Depends(require_role(Role.DOCTOR))):
    return doctor_service.get_my_profile(db, user)


@router.put("/me", response_model=DoctorOut, summary="Update my doctor profile (DOCTOR)")
def update_my_profile(data: DoctorUpdate, db: Session = Depends(get_db),
                      user: CurrentUser = Depends(require_role(Role.DOCTOR))):
    return doctor_service.update_my_profile(db, user, data)


# keep this one after /me, otherwise "me" would be read as a doctor id
@router.get("/{doctor_id}", response_model=DoctorOut, summary="View one doctor")
def view_doctor(doctor_id: int, db: Session = Depends(get_db), user: CurrentUser = Depends(get_current_user)):
    return doctor_service.view_doctor(db, user, doctor_id)
