"""Called by the other services only (the gateway does not route /internal)."""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from services.doctor_service.app.database import get_db
from services.doctor_service.app.schemas.doctor import ActiveFlag, DoctorInternalOut
from services.doctor_service.app.services import doctor_service
from shared.dependencies import require_internal_key

router = APIRouter(prefix="/internal/doctors", include_in_schema=False, dependencies=[Depends(require_internal_key)])


@router.get("/by-user/{user_id}", response_model=DoctorInternalOut)
def doctor_by_user(user_id: int, db: Session = Depends(get_db)):
    return doctor_service.get_doctor_by_user(db, user_id)


@router.patch("/by-user/{user_id}/active", response_model=DoctorInternalOut)
def set_active(user_id: int, data: ActiveFlag, db: Session = Depends(get_db)):
    return doctor_service.set_active(db, user_id, data.is_active)


@router.get("/{doctor_id}", response_model=DoctorInternalOut)
def doctor_by_id(doctor_id: int, db: Session = Depends(get_db)):
    return doctor_service.get_doctor(db, doctor_id)
