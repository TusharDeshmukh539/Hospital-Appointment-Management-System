from typing import Optional

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from services.doctor_service.app.models.doctor import Doctor
from services.doctor_service.app.models.speciality import Speciality
from shared.pagination import paginate, sort_clauses

SORTABLE = {"name": [Speciality.name, Speciality.id], "id": [Speciality.id]}


def get_by_id(db: Session, speciality_id: int) -> Optional[Speciality]:
    return db.get(Speciality, speciality_id)


def get_by_name(db: Session, name: str) -> Optional[Speciality]:
    return db.scalar(select(Speciality).where(func.lower(Speciality.name) == name.lower()))


def list_all(db: Session, sort_by: str, order: Optional[str], page: int, size: int) -> dict:
    return paginate(db, select(Speciality).order_by(*sort_clauses(SORTABLE, sort_by, order, "name")), page, size)


def create(db: Session, name: str) -> Speciality:
    speciality = Speciality(name=name)
    db.add(speciality)
    db.flush()
    return speciality


def delete(db: Session, speciality: Speciality) -> None:
    db.delete(speciality)
    db.flush()


def count_doctors(db: Session, speciality_id: int) -> int:
    return db.scalar(select(func.count(Doctor.id)).where(Doctor.speciality_id == speciality_id))
