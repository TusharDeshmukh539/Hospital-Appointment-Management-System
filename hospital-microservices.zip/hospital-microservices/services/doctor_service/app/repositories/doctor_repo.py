from typing import Optional

from sqlalchemy import func, select
from sqlalchemy.orm import Session, joinedload

from services.doctor_service.app.models.doctor import Doctor
from services.doctor_service.app.models.speciality import Speciality
from shared.pagination import paginate, sort_clauses

SORTABLE = {"full_name": [Doctor.full_name, Doctor.id],
            "experience_years": [Doctor.experience_years, Doctor.full_name, Doctor.id],
            "consultation_fee": [Doctor.consultation_fee, Doctor.full_name, Doctor.id]}


def get_by_id(db: Session, doctor_id: int) -> Optional[Doctor]:
    return db.scalar(select(Doctor).where(Doctor.id == doctor_id).options(joinedload(Doctor.speciality)))


def get_by_user_id(db: Session, user_id: int) -> Optional[Doctor]:
    return db.scalar(select(Doctor).where(Doctor.user_id == user_id).options(joinedload(Doctor.speciality)))


def get_by_registration_no(db: Session, registration_no: str) -> Optional[Doctor]:
    return db.scalar(select(Doctor).where(Doctor.registration_no == registration_no))


def create(db: Session, **fields) -> Doctor:
    doctor = Doctor(**fields, is_active=True)
    db.add(doctor)
    db.flush()
    return doctor


def search(db: Session, speciality: Optional[str], name: Optional[str], sort_by: str, order: Optional[str],
           page: int, size: int) -> dict:
    """Active doctors, filtered by speciality name and/or doctor name (contains, any case)."""
    query = (select(Doctor).join(Speciality, Doctor.speciality_id == Speciality.id)
             .where(Doctor.is_active.is_(True)).options(joinedload(Doctor.speciality)))
    if speciality:
        query = query.where(func.lower(Speciality.name).like(f"%{speciality.lower()}%"))
    if name:
        query = query.where(func.lower(Doctor.full_name).like(f"%{name.lower()}%"))
    return paginate(db, query.order_by(*sort_clauses(SORTABLE, sort_by, order, "full_name")), page, size)
