"""Doctor service: specialities and doctor profiles. Database: DOCTOR_DATABASE_URL."""
from fastapi import FastAPI

from services.doctor_service.app import models  # noqa: F401
from services.doctor_service.app.routes import doctors, internal, specialities
from shared.exceptions import add_error_handlers

app = FastAPI(title="Doctor service", docs_url=None, redoc_url=None, openapi_url=None)
add_error_handlers(app)
app.include_router(specialities.router)
app.include_router(doctors.router)
app.include_router(internal.router)
