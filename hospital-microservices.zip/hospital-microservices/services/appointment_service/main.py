"""Appointment service: bookings, consultations and admin reports. Database: APPOINTMENT_DATABASE_URL."""
from fastapi import FastAPI

from services.appointment_service.app import models  # noqa: F401
from services.appointment_service.app.routes import appointments, consultations, reports
from shared.exceptions import add_error_handlers

app = FastAPI(title="Appointment service", docs_url=None, redoc_url=None, openapi_url=None)
add_error_handlers(app)
app.include_router(appointments.router)
app.include_router(consultations.router)
app.include_router(reports.router)
