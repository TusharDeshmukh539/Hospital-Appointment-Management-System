from datetime import date, datetime, time
from typing import Optional

from sqlalchemy import and_, func, not_, or_, select
from sqlalchemy.orm import Session

from services.appointment_service.app.models.appointment import Appointment
from shared.enums import AppointmentStatus
from shared.pagination import paginate, sort_clauses

PATIENT_SORTABLE = {
    "slot_date": [Appointment.slot_date, Appointment.start_time, Appointment.id],
    "doctor_name": [Appointment.doctor_name, Appointment.slot_date, Appointment.start_time],
    "status": [Appointment.status, Appointment.slot_date, Appointment.start_time],
    "booked_at": [Appointment.booked_at, Appointment.id]}
DOCTOR_SORTABLE = {
    "start_time": [Appointment.start_time, Appointment.id],
    "patient_name": [Appointment.patient_name, Appointment.start_time],
    "status": [Appointment.status, Appointment.start_time]}


def create(db: Session, slot: dict, patient: dict, doctor: dict, reason: Optional[str]) -> Appointment:
    appointment = Appointment(
        slot_id=slot["id"], doctor_id=doctor["id"], patient_id=patient["id"],
        doctor_name=doctor["full_name"], patient_name=patient["full_name"],
        slot_date=date.fromisoformat(slot["slot_date"]),
        start_time=time.fromisoformat(slot["start_time"]),
        end_time=time.fromisoformat(slot["end_time"]),
        status=AppointmentStatus.BOOKED.value, reason=reason)
    db.add(appointment)
    db.flush()
    return appointment


def get_for_patient(db: Session, appointment_id: int, patient_id: int) -> Optional[Appointment]:
    """Only finds the appointment if it belongs to this patient."""
    return db.scalar(select(Appointment).where(
        Appointment.id == appointment_id, Appointment.patient_id == patient_id))


def get_for_doctor(db: Session, appointment_id: int, doctor_id: int) -> Optional[Appointment]:
    """Only finds the appointment if it belongs to this doctor."""
    return db.scalar(select(Appointment).where(
        Appointment.id == appointment_id, Appointment.doctor_id == doctor_id))


def patient_has_booking_on_date(db: Session, patient_id: int, doctor_id: int, day: date,
                                exclude_id: Optional[int] = None) -> bool:
    query = select(func.count(Appointment.id)).where(
        Appointment.patient_id == patient_id, Appointment.doctor_id == doctor_id,
        Appointment.status == AppointmentStatus.BOOKED.value, Appointment.slot_date == day)
    if exclude_id is not None:
        query = query.where(Appointment.id != exclude_id)
    return db.scalar(query) > 0


def list_for_patient(db: Session, patient_id: int, when: str, now: datetime, sort_by: str,
                     order: Optional[str], page: int, size: int) -> dict:
    """`when` is upcoming (still BOOKED and in the future), past (everything else) or all."""
    upcoming = and_(
        Appointment.status == AppointmentStatus.BOOKED.value,
        or_(Appointment.slot_date > now.date(),
            and_(Appointment.slot_date == now.date(), Appointment.start_time >= now.time())))
    query = select(Appointment).where(Appointment.patient_id == patient_id)
    if when == "upcoming":
        query = query.where(upcoming)
    elif when == "past":
        query = query.where(not_(upcoming))
    return paginate(db, query.order_by(*sort_clauses(PATIENT_SORTABLE, sort_by, order, "slot_date")), page, size)


def list_for_doctor_on_date(db: Session, doctor_id: int, day: date, sort_by: str, order: Optional[str],
                            page: int, size: int) -> dict:
    query = select(Appointment).where(Appointment.doctor_id == doctor_id, Appointment.slot_date == day)
    return paginate(db, query.order_by(*sort_clauses(DOCTOR_SORTABLE, sort_by, order, "start_time")), page, size)


def count_by_doctor_and_status(db: Session, from_date: Optional[date], to_date: Optional[date]) -> list:
    """Rows of (doctor_id, doctor_name, status, count) for appointments whose slot date is in the range."""
    query = select(Appointment.doctor_id, Appointment.doctor_name, Appointment.status, func.count(Appointment.id))
    if from_date:
        query = query.where(Appointment.slot_date >= from_date)
    if to_date:
        query = query.where(Appointment.slot_date <= to_date)
    query = query.group_by(Appointment.doctor_id, Appointment.doctor_name, Appointment.status)
    return list(db.execute(query.order_by(Appointment.doctor_name, Appointment.doctor_id)).all())

