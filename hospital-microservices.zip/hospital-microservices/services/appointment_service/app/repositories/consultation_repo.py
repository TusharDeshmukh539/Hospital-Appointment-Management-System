from typing import Optional

from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload

from services.appointment_service.app.models.appointment import Appointment
from services.appointment_service.app.models.consultation import Consultation
from shared.pagination import paginate, sort_clauses

SORTABLE = {"appointment_date": [Appointment.slot_date, Consultation.id], "id": [Consultation.id]}


def get_by_appointment_id(db: Session, appointment_id: int) -> Optional[Consultation]:
    return db.scalar(select(Consultation).where(Consultation.appointment_id == appointment_id)
                     .options(joinedload(Consultation.appointment)))


def get_by_id(db: Session, consultation_id: int) -> Optional[Consultation]:
    return db.scalar(select(Consultation).where(Consultation.id == consultation_id)
                     .options(joinedload(Consultation.appointment)))


def create(db: Session, appointment_id: int, **fields) -> Consultation:
    consultation = Consultation(appointment_id=appointment_id, **fields)
    db.add(consultation)
    db.flush()
    return consultation


def list_for_patient(db: Session, patient_id: int, sort_by: str, order: Optional[str], page: int, size: int) -> dict:
    """The patient's consultations (newest appointment first unless sorted otherwise)."""
    query = (select(Consultation).join(Appointment, Consultation.appointment_id == Appointment.id)
             .where(Appointment.patient_id == patient_id).options(joinedload(Consultation.appointment))
             .order_by(*sort_clauses(SORTABLE, sort_by, order, "appointment_date", "desc")))
    return paginate(db, query, page, size)
