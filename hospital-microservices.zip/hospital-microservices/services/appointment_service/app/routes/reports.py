from datetime import date
from typing import Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from services.appointment_service.app.database import get_db
from services.appointment_service.app.schemas.report import AppointmentReport
from services.appointment_service.app.services import report_service
from shared.dependencies import require_role
from shared.enums import Role

router = APIRouter(prefix="/admin/reports", tags=["Reports (admin)"])


@router.get("/appointments", response_model=AppointmentReport,
            summary="Appointments per status and per doctor (ADMIN)")
def appointment_report(from_date: Optional[date] = Query(None), to_date: Optional[date] = Query(None),
                       db: Session = Depends(get_db), _=Depends(require_role(Role.ADMIN))):
    return report_service.appointment_report(db, from_date, to_date)
