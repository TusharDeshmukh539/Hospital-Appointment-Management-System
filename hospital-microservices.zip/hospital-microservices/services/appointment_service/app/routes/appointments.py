from datetime import date
from typing import Literal, Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from services.appointment_service.app.database import get_db
from services.appointment_service.app.schemas.appointment import (
    AppointmentCreate, AppointmentOut, AppointmentReschedule, AppointmentStatusUpdate)
from services.appointment_service.app.schemas.consultation import ConsultationCreate, ConsultationOut
from services.appointment_service.app.services import appointment_service, consultation_service
from shared.dependencies import CurrentUser, require_role
from shared.enums import Role
from shared.pagination import Page, SortOrder

router = APIRouter(prefix="/appointments", tags=["Appointments"])
patient_only = require_role(Role.PATIENT)
doctor_only = require_role(Role.DOCTOR)


@router.post("", response_model=AppointmentOut, status_code=201, summary="Book a free slot (PATIENT)")
def book(data: AppointmentCreate, db: Session = Depends(get_db), user: CurrentUser = Depends(patient_only)):
    return appointment_service.book_appointment(db, user, data)


@router.get("/me", response_model=Page[AppointmentOut], summary="My upcoming and past appointments (PATIENT)")
def my_appointments(when: Literal["upcoming", "past", "all"] = "all",
                    sort_by: Literal["slot_date", "doctor_name", "status", "booked_at"] = "slot_date",
                    order: Optional[SortOrder] = Query(None, description="asc (default) or desc"),
                    page: int = Query(1, ge=1), size: int = Query(10, ge=1, le=100),
                    db: Session = Depends(get_db), user: CurrentUser = Depends(patient_only)):
    return appointment_service.list_my_appointments(db, user, when, sort_by, order, page, size)


@router.get("/doctor", response_model=Page[AppointmentOut], summary="My appointments for a day (DOCTOR)")
def doctor_appointments(slot_date: Optional[date] = Query(None, alias="date", description="Defaults to today"),
                        sort_by: Literal["start_time", "patient_name", "status"] = "start_time",
                        order: Optional[SortOrder] = Query(None, description="asc (default) or desc"),
                        page: int = Query(1, ge=1), size: int = Query(10, ge=1, le=100),
                        db: Session = Depends(get_db), user: CurrentUser = Depends(doctor_only)):
    return appointment_service.list_doctor_appointments(db, user, slot_date, sort_by, order, page, size)


@router.patch("/{appointment_id}/reschedule", response_model=AppointmentOut,
              summary="Move my appointment to another free slot (PATIENT)")
def reschedule(appointment_id: int, data: AppointmentReschedule, db: Session = Depends(get_db),
               user: CurrentUser = Depends(patient_only)):
    return appointment_service.reschedule_appointment(db, user, appointment_id, data)


@router.patch("/{appointment_id}/cancel", response_model=AppointmentOut,
              summary="Cancel my appointment before the cut-off (PATIENT)")
def cancel(appointment_id: int, db: Session = Depends(get_db), user: CurrentUser = Depends(patient_only)):
    return appointment_service.cancel_appointment(db, user, appointment_id)


@router.patch("/{appointment_id}/status", response_model=AppointmentOut,
              summary="Mark COMPLETED or NO_SHOW (DOCTOR)")
def update_status(appointment_id: int, data: AppointmentStatusUpdate, db: Session = Depends(get_db),
                  user: CurrentUser = Depends(doctor_only)):
    return appointment_service.update_status(db, user, appointment_id, data)


@router.post("/{appointment_id}/consultation", response_model=ConsultationOut, status_code=201,
             summary="Record diagnosis, prescription and follow-up (DOCTOR)")
def record_consultation(appointment_id: int, data: ConsultationCreate, db: Session = Depends(get_db),
                        user: CurrentUser = Depends(doctor_only)):
    return consultation_service.record_consultation(db, user, appointment_id, data)
