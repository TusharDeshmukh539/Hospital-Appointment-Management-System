from typing import Literal, Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from services.appointment_service.app.database import get_db
from services.appointment_service.app.schemas.consultation import ConsultationOut
from services.appointment_service.app.services import consultation_service
from shared.dependencies import CurrentUser, require_role
from shared.enums import Role
from shared.pagination import Page, SortOrder

router = APIRouter(prefix="/consultations", tags=["Consultations"])


@router.get("/me", response_model=Page[ConsultationOut], summary="My consultation history (PATIENT)")
def my_consultations(sort_by: Literal["appointment_date", "id"] = "appointment_date",
                     order: Optional[SortOrder] = Query(None, description="desc (default) or asc"),
                     page: int = Query(1, ge=1), size: int = Query(10, ge=1, le=100),
                     db: Session = Depends(get_db), user: CurrentUser = Depends(require_role(Role.PATIENT))):
    return consultation_service.list_my_consultations(db, user, sort_by, order, page, size)


# keep this one after /me, otherwise "me" would be read as a consultation id
@router.get("/{consultation_id}", response_model=ConsultationOut,
            summary="View one consultation (its PATIENT or its DOCTOR)")
def view_consultation(consultation_id: int, db: Session = Depends(get_db),
                      user: CurrentUser = Depends(require_role(Role.PATIENT, Role.DOCTOR))):
    return consultation_service.get_consultation(db, user, consultation_id)
