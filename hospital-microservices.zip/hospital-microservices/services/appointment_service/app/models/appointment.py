from datetime import date, datetime, time
from typing import Optional

from sqlalchemy import Date, DateTime, Integer, String, Time
from sqlalchemy.orm import Mapped, mapped_column

from services.appointment_service.app.database import Base
from shared.enums import AppointmentStatus
from shared.models import TimestampMixin, utc_now


class Appointment(Base, TimestampMixin):
    __tablename__ = "appointments"

    id: Mapped[int] = mapped_column(primary_key=True)
    # ids that belong to other services
    slot_id: Mapped[int] = mapped_column(Integer, index=True)  # schedule service
    doctor_id: Mapped[int] = mapped_column(Integer, index=True)  # doctor service
    patient_id: Mapped[int] = mapped_column(Integer, index=True)  # patient service
    # copied when the appointment is booked, so lists never have to call the other services
    doctor_name: Mapped[str] = mapped_column(String(100))
    patient_name: Mapped[str] = mapped_column(String(100))
    slot_date: Mapped[date] = mapped_column(Date, index=True)
    start_time: Mapped[time] = mapped_column(Time)
    end_time: Mapped[time] = mapped_column(Time)

    status: Mapped[str] = mapped_column(String(20), default=AppointmentStatus.BOOKED.value)
    reason: Mapped[Optional[str]] = mapped_column(String(255))
    booked_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    cancelled_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
