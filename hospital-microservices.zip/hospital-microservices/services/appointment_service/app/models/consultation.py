from datetime import date
from typing import Optional

from sqlalchemy import Date, ForeignKey, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from services.appointment_service.app.database import Base
from shared.models import TimestampMixin


class Consultation(Base, TimestampMixin):
    __tablename__ = "consultations"

    id: Mapped[int] = mapped_column(primary_key=True)
    appointment_id: Mapped[int] = mapped_column(ForeignKey("appointments.id"), unique=True)
    diagnosis: Mapped[str] = mapped_column(Text)
    prescription: Mapped[str] = mapped_column(Text)
    notes: Mapped[Optional[str]] = mapped_column(Text)
    follow_up_date: Mapped[Optional[date]] = mapped_column(Date)

    appointment = relationship("Appointment")

    @property
    def doctor_name(self) -> str:
        return self.appointment.doctor_name

    @property
    def appointment_date(self) -> date:
        return self.appointment.slot_date
