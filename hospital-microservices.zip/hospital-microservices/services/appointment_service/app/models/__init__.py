from services.appointment_service.app.models.appointment import Appointment
from services.appointment_service.app.models.consultation import Consultation

__all__ = ["Appointment", "Consultation"]
