from sqlalchemy.orm import Session

from services.appointment_service.app.repositories import appointment_repo, consultation_repo
from services.appointment_service.app.schemas.consultation import ConsultationCreate
from services.appointment_service.app.services.appointment_service import get_my_doctor, get_my_patient
from shared import audit
from shared.dependencies import CurrentUser
from shared.enums import AppointmentStatus, Role
from shared.exceptions import ConflictError, NotFoundError


def record_consultation(db: Session, user: CurrentUser, appointment_id: int, data: ConsultationCreate):
    """Story 19: only the appointment's own doctor, only once it is COMPLETED."""
    doctor = get_my_doctor(user)
    appointment = appointment_repo.get_for_doctor(db, appointment_id, doctor["id"])
    if appointment is None:
        raise NotFoundError("Appointment not found")
    if appointment.status != AppointmentStatus.COMPLETED.value:
        raise ConflictError("A consultation can only be recorded for a COMPLETED appointment")
    if consultation_repo.get_by_appointment_id(db, appointment_id):
        raise ConflictError("A consultation has already been recorded for this appointment")
    consultation_repo.create(db, appointment_id, diagnosis=data.diagnosis, prescription=data.prescription,
                             notes=data.notes, follow_up_date=data.follow_up_date)
    db.commit()
    consultation = consultation_repo.get_by_appointment_id(db, appointment_id)
    audit.record(user, "CONSULTATION_RECORDED", "consultation", consultation.id, f"appointment_id={appointment_id}")
    return consultation


def list_my_consultations(db: Session, user: CurrentUser, sort_by: str, order, page: int, size: int) -> dict:
    """Story 20."""
    patient = get_my_patient(user)
    return consultation_repo.list_for_patient(db, patient["id"], sort_by, order, page, size)


def get_consultation(db: Session, user: CurrentUser, consultation_id: int):
    """One consultation, only for the patient it was about or the doctor who recorded it (404 for anyone else)."""
    consultation = consultation_repo.get_by_id(db, consultation_id)
    if consultation is None:
        raise NotFoundError("Consultation not found")
    appointment = consultation.appointment
    if user.role == Role.PATIENT.value:
        allowed = appointment.patient_id == get_my_patient(user)["id"]
    else:
        allowed = appointment.doctor_id == get_my_doctor(user)["id"]
    if not allowed:
        raise NotFoundError("Consultation not found")
    return consultation
