from datetime import date
from typing import Optional

from sqlalchemy.orm import Session

from services.appointment_service.app.repositories import appointment_repo
from shared.enums import AppointmentStatus
from shared.exceptions import BadRequestError


def _zero_counts() -> dict:
    return {status.value: 0 for status in AppointmentStatus}


def appointment_report(db: Session, from_date: Optional[date], to_date: Optional[date]) -> dict:
    """Admin report: appointments per status, in total and per doctor (by slot date, range optional)."""
    if from_date and to_date and to_date < from_date:
        raise BadRequestError("to_date must not be before from_date")
    by_status = _zero_counts()
    doctors: dict[int, dict] = {}
    for doctor_id, doctor_name, status, count in appointment_repo.count_by_doctor_and_status(db, from_date, to_date):
        row = doctors.setdefault(doctor_id, {"doctor_id": doctor_id, "doctor_name": doctor_name,
                                             "total": 0, **_zero_counts()})
        row[status] += count
        row["total"] += count
        by_status[status] += count
    return {"from_date": from_date, "to_date": to_date, "total": sum(by_status.values()),
            "by_status": by_status, "by_doctor": list(doctors.values())}
