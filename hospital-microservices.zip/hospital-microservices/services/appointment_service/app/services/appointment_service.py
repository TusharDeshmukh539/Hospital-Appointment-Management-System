from datetime import date, datetime, time, timedelta, timezone
from typing import Optional

from sqlalchemy.orm import Session

from services.appointment_service.app.repositories import appointment_repo
from services.appointment_service.app.schemas.appointment import (
    AppointmentCreate, AppointmentReschedule, AppointmentStatusUpdate)
from shared import audit
from shared.client import call
from shared.config import settings
from shared.dependencies import CurrentUser
from shared.enums import AppointmentStatus, SlotStatus
from shared.exceptions import BadRequestError, ConflictError, NotFoundError


def utc_now() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def get_my_patient(user: CurrentUser) -> dict:
    return call("patient", "GET", f"/internal/patients/by-user/{user.id}")


def get_my_doctor(user: CurrentUser) -> dict:
    return call("doctor", "GET", f"/internal/doctors/by-user/{user.id}")


def _bookable_slot(slot_id: int) -> tuple[dict, dict]:
    """Fetch a slot and its doctor; reject it unless it can be booked right now."""
    slot = call("schedule", "GET", f"/internal/slots/{slot_id}")  # 404 if the slot does not exist
    doctor = call("doctor", "GET", f"/internal/doctors/{slot['doctor_id']}")
    if not doctor["is_active"]:
        raise ConflictError("This doctor is not available")
    start = datetime.combine(date.fromisoformat(slot["slot_date"]), time.fromisoformat(slot["start_time"]))
    if start <= utc_now():
        raise BadRequestError("Slots in the past cannot be booked")
    if slot["status"] != SlotStatus.FREE.value:
        raise ConflictError(f"This slot is not available (status: {slot['status']})")
    return slot, doctor


def _claim(slot_id: int) -> None:
    if not call("schedule", "POST", f"/internal/slots/{slot_id}/claim")["claimed"]:
        raise ConflictError("This slot has just been booked by someone else")


def _release(slot_id: int) -> None:
    call("schedule", "POST", f"/internal/slots/{slot_id}/release")


def book_appointment(db: Session, user: CurrentUser, data: AppointmentCreate):
    """Story 13. The slot is claimed first (atomic FREE -> BOOKED), then the appointment is saved."""
    patient = get_my_patient(user)
    slot, doctor = _bookable_slot(data.slot_id)
    if appointment_repo.patient_has_booking_on_date(
            db, patient["id"], doctor["id"], date.fromisoformat(slot["slot_date"])):
        raise ConflictError("You already have an appointment with this doctor on that day")

    _claim(slot["id"])
    try:
        appointment = appointment_repo.create(db, slot, patient, doctor, data.reason)
        db.commit()
    except Exception:  # give the slot back if the appointment could not be saved
        db.rollback()
        _release(slot["id"])
        raise
    audit.record(user, "APPOINTMENT_BOOKED", "appointment", appointment.id, f"slot_id={slot['id']}")
    return appointment


def reschedule_appointment(db: Session, user: CurrentUser, appointment_id: int, data: AppointmentReschedule):
    """Story 14: move to another free slot of the same doctor."""
    patient = get_my_patient(user)
    appointment = appointment_repo.get_for_patient(db, appointment_id, patient["id"])
    if appointment is None:
        raise NotFoundError("Appointment not found")
    if appointment.status != AppointmentStatus.BOOKED.value:
        raise ConflictError("Only BOOKED appointments can be rescheduled")
    if data.new_slot_id == appointment.slot_id:
        raise BadRequestError("The new slot is the same as the current slot")

    new_slot, _ = _bookable_slot(data.new_slot_id)
    if new_slot["doctor_id"] != appointment.doctor_id:
        raise BadRequestError("You can only reschedule to another slot of the same doctor")
    new_day = date.fromisoformat(new_slot["slot_date"])
    if appointment_repo.patient_has_booking_on_date(
            db, patient["id"], appointment.doctor_id, new_day, exclude_id=appointment.id):
        raise ConflictError("You already have an appointment with this doctor on that day")

    old_slot_id = appointment.slot_id
    _claim(new_slot["id"])
    try:
        appointment.slot_id = new_slot["id"]
        appointment.slot_date = new_day
        appointment.start_time = time.fromisoformat(new_slot["start_time"])
        appointment.end_time = time.fromisoformat(new_slot["end_time"])
        db.commit()
    except Exception:
        db.rollback()
        _release(new_slot["id"])
        raise
    _release(old_slot_id)
    audit.record(user, "APPOINTMENT_RESCHEDULED", "appointment", appointment.id,
                 f"slot {old_slot_id} -> {new_slot['id']}")
    return appointment


def cancel_appointment(db: Session, user: CurrentUser, appointment_id: int):
    """Story 15: only until CANCELLATION_CUTOFF_HOURS before the slot starts."""
    patient = get_my_patient(user)
    appointment = appointment_repo.get_for_patient(db, appointment_id, patient["id"])
    if appointment is None:
        raise NotFoundError("Appointment not found")
    if appointment.status != AppointmentStatus.BOOKED.value:
        raise ConflictError("Only BOOKED appointments can be cancelled")
    hours = settings.CANCELLATION_CUTOFF_HOURS
    if utc_now() > datetime.combine(appointment.slot_date, appointment.start_time) - timedelta(hours=hours):
        raise BadRequestError(f"Appointments can only be cancelled at least {hours} hours before the slot")

    appointment.status = AppointmentStatus.CANCELLED.value
    appointment.cancelled_at = datetime.now(timezone.utc)
    db.commit()
    _release(appointment.slot_id)  # free the slot only after the cancellation is saved
    audit.record(user, "APPOINTMENT_CANCELLED", "appointment", appointment.id)
    return appointment


def list_my_appointments(db: Session, user: CurrentUser, when: str, sort_by: str, order: Optional[str],
                         page: int, size: int) -> dict:
    """Story 16."""
    patient = get_my_patient(user)
    return appointment_repo.list_for_patient(db, patient["id"], when, utc_now(), sort_by, order, page, size)


def list_doctor_appointments(db: Session, user: CurrentUser, day: Optional[date], sort_by: str,
                             order: Optional[str], page: int, size: int) -> dict:
    """Story 17 (defaults to today)."""
    doctor = get_my_doctor(user)
    return appointment_repo.list_for_doctor_on_date(db, doctor["id"], day or utc_now().date(), sort_by, order, page, size)


def update_status(db: Session, user: CurrentUser, appointment_id: int, data: AppointmentStatusUpdate):
    """Story 18."""
    doctor = get_my_doctor(user)
    appointment = appointment_repo.get_for_doctor(db, appointment_id, doctor["id"])
    if appointment is None:
        raise NotFoundError("Appointment not found")
    if appointment.status != AppointmentStatus.BOOKED.value:
        raise ConflictError(f"Appointment is already {appointment.status}")
    appointment.status = data.status
    db.commit()
    audit.record(user, "APPOINTMENT_" + data.status, "appointment", appointment.id)
    return appointment
