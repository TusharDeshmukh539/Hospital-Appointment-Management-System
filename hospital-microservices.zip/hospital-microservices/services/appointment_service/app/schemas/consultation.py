from datetime import date, datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


class ConsultationCreate(BaseModel):
    diagnosis: str = Field(min_length=1, max_length=5000)
    prescription: str = Field(min_length=1, max_length=5000)
    notes: Optional[str] = Field(default=None, max_length=5000)
    follow_up_date: Optional[date] = None

    @field_validator("follow_up_date")
    @classmethod
    def not_in_the_past(cls, value: Optional[date]) -> Optional[date]:
        if value and value < date.today():
            raise ValueError("follow_up_date cannot be in the past")
        return value


class ConsultationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    appointment_id: int
    doctor_name: str
    appointment_date: date
    diagnosis: str
    prescription: str
    notes: Optional[str]
    follow_up_date: Optional[date]
    created_at: datetime
    updated_at: datetime
