from datetime import date
from typing import Optional

from pydantic import BaseModel


class StatusCounts(BaseModel):
    BOOKED: int = 0
    COMPLETED: int = 0
    CANCELLED: int = 0
    NO_SHOW: int = 0


class DoctorReport(StatusCounts):
    doctor_id: int
    doctor_name: str
    total: int = 0


class AppointmentReport(BaseModel):
    from_date: Optional[date]
    to_date: Optional[date]
    total: int
    by_status: StatusCounts
    by_doctor: list[DoctorReport]
