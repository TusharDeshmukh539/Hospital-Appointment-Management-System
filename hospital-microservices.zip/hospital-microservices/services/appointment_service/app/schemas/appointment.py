from datetime import date, datetime, time
from typing import Literal, Optional

from pydantic import BaseModel, ConfigDict, Field


class AppointmentCreate(BaseModel):
    slot_id: int = Field(gt=0)
    reason: Optional[str] = Field(default=None, max_length=255)


class AppointmentReschedule(BaseModel):
    new_slot_id: int = Field(gt=0)


class AppointmentStatusUpdate(BaseModel):
    status: Literal["COMPLETED", "NO_SHOW"]


class AppointmentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    slot_id: int
    doctor_id: int
    patient_id: int
    doctor_name: str
    patient_name: str
    slot_date: date
    start_time: time
    end_time: time
    status: str
    reason: Optional[str]
    booked_at: datetime
    cancelled_at: Optional[datetime]
    created_at: datetime
    updated_at: datetime
