"""Schedule service: weekly availability and slots. Database: SCHEDULE_DATABASE_URL."""
from fastapi import FastAPI

from services.schedule_service.app import models  # noqa: F401
from services.schedule_service.app.routes import availability, internal, slots
from shared.exceptions import add_error_handlers

app = FastAPI(title="Schedule service", docs_url=None, redoc_url=None, openapi_url=None)
add_error_handlers(app)
app.include_router(availability.router)
app.include_router(slots.router)
app.include_router(internal.router)
