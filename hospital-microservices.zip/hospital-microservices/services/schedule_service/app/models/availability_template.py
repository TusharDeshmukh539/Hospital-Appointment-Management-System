from datetime import time

from sqlalchemy import Integer, Time
from sqlalchemy.orm import Mapped, mapped_column

from services.schedule_service.app.database import Base
from shared.models import TimestampMixin


class AvailabilityTemplate(Base, TimestampMixin):
    """A weekly window, e.g. 'every Monday 09:00-13:00 in 30 minute slots'."""

    __tablename__ = "availability_templates"

    id: Mapped[int] = mapped_column(primary_key=True)
    doctor_id: Mapped[int] = mapped_column(Integer, index=True)  # doctor id in the doctor service
    weekday: Mapped[int] = mapped_column(Integer)  # Monday = 0 ... Sunday = 6
    start_time: Mapped[time] = mapped_column(Time)
    end_time: Mapped[time] = mapped_column(Time)
    slot_minutes: Mapped[int] = mapped_column(Integer)
