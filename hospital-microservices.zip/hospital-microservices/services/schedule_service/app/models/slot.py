from datetime import date, time

from sqlalchemy import Date, Integer, String, Time, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from services.schedule_service.app.database import Base
from shared.enums import SlotStatus
from shared.models import TimestampMixin


class Slot(Base, TimestampMixin):
    __tablename__ = "slots"
    __table_args__ = (UniqueConstraint("doctor_id", "slot_date", "start_time"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    doctor_id: Mapped[int] = mapped_column(Integer, index=True)  # doctor id in the doctor service
    slot_date: Mapped[date] = mapped_column(Date)
    start_time: Mapped[time] = mapped_column(Time)
    end_time: Mapped[time] = mapped_column(Time)
    status: Mapped[str] = mapped_column(String(10), default=SlotStatus.FREE.value)
