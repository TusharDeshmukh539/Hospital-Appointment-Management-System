from services.schedule_service.app.models.availability_template import AvailabilityTemplate
from services.schedule_service.app.models.slot import Slot

__all__ = ["AvailabilityTemplate", "Slot"]
