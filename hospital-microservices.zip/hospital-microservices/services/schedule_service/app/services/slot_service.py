from datetime import date, datetime, timedelta, timezone

from sqlalchemy.orm import Session

from services.schedule_service.app.models.slot import Slot
from services.schedule_service.app.repositories import availability_repo, slot_repo
from services.schedule_service.app.schemas.availability import BlockDateRequest, SlotGenerateRequest
from services.schedule_service.app.services.availability_service import get_my_doctor_id
from shared import audit
from shared.client import call
from shared.dependencies import CurrentUser
from shared.enums import SlotStatus
from shared.exceptions import BadRequestError, ConflictError, NotFoundError


def generate_slots(db: Session, user: CurrentUser, data: SlotGenerateRequest) -> dict:
    """Story 7: turn the weekly windows into bookable slots for a date range."""
    doctor_id = get_my_doctor_id(user)
    templates = availability_repo.list_for_doctor(db, doctor_id)
    if not templates:
        raise BadRequestError("Define your weekly availability first")

    existing = [(s.slot_date, s.start_time) for s in slot_repo.list_in_range(db, doctor_id, data.from_date, data.to_date)]
    new_slots, skipped = [], 0
    day = data.from_date
    while day <= data.to_date:
        for template in templates:
            if template.weekday != day.weekday():
                continue
            step = timedelta(minutes=template.slot_minutes)
            start = datetime.combine(day, template.start_time)
            end = datetime.combine(day, template.end_time)
            while start + step <= end:
                if (day, start.time()) in existing:
                    skipped += 1
                else:
                    new_slots.append(Slot(doctor_id=doctor_id, slot_date=day, start_time=start.time(),
                                          end_time=(start + step).time(), status=SlotStatus.FREE.value))
                start += step
        day += timedelta(days=1)

    slot_repo.add_many(db, new_slots)
    db.commit()
    audit.record(user, "SLOTS_GENERATED", "doctor", doctor_id,
                 f"{data.from_date} to {data.to_date}: {len(new_slots)} created")
    return {"created": len(new_slots), "skipped": skipped}


def list_my_slots(db: Session, user: CurrentUser, slot_date: date):
    return slot_repo.list_for_doctor_on_date(db, get_my_doctor_id(user), slot_date)


def list_free_slots(db: Session, doctor_id: int, slot_date: date):
    """Story 10: free slots that have not started yet (404 if the doctor is unknown or deactivated)."""
    doctor = call("doctor", "GET", f"/internal/doctors/{doctor_id}")
    if not doctor["is_active"]:
        raise NotFoundError("Doctor not found")
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    slots = slot_repo.list_for_doctor_on_date(db, doctor_id, slot_date, SlotStatus.FREE.value)
    return [s for s in slots if datetime.combine(s.slot_date, s.start_time) >= now]


def block_slot(db: Session, user: CurrentUser, slot_id: int):
    """Story 8: block one of my free slots."""
    slot = slot_repo.get_by_id(db, slot_id)
    if slot is None or slot.doctor_id != get_my_doctor_id(user):
        raise NotFoundError("Slot not found")
    if not slot_repo.change_status(db, slot_id, SlotStatus.FREE, SlotStatus.BLOCKED):
        raise ConflictError(f"Only FREE slots can be blocked (this slot is {slot.status})")
    db.commit()
    audit.record(user, "SLOT_BLOCKED", "slot", slot_id)
    db.expire_all()
    return slot_repo.get_by_id(db, slot_id)


def unblock_slot(db: Session, user: CurrentUser, slot_id: int):
    """Undo story 8: put one of my BLOCKED slots back to FREE."""
    slot = slot_repo.get_by_id(db, slot_id)
    if slot is None or slot.doctor_id != get_my_doctor_id(user):
        raise NotFoundError("Slot not found")
    if not slot_repo.change_status(db, slot_id, SlotStatus.BLOCKED, SlotStatus.FREE):
        raise ConflictError(f"Only BLOCKED slots can be unblocked (this slot is {slot.status})")
    db.commit()
    audit.record(user, "SLOT_UNBLOCKED", "slot", slot_id)
    db.expire_all()
    return slot_repo.get_by_id(db, slot_id)


def block_date(db: Session, user: CurrentUser, data: BlockDateRequest) -> dict:
    """Story 8: block every free slot of a date (e.g. a leave day). Booked slots are left alone."""
    doctor_id = get_my_doctor_id(user)
    blocked = slot_repo.block_free_slots_on_date(db, doctor_id, data.slot_date)
    already_booked = slot_repo.count_booked_on_date(db, doctor_id, data.slot_date)
    db.commit()
    audit.record(user, "DATE_BLOCKED", "doctor", doctor_id, f"{data.slot_date}: {blocked} blocked")
    return {"blocked": blocked, "already_booked": already_booked}


# ---- used by the appointment service ----

def get_slot(db: Session, slot_id: int):
    slot = slot_repo.get_by_id(db, slot_id)
    if slot is None:
        raise NotFoundError("Slot not found")
    return slot


def claim_slot(db: Session, slot_id: int) -> bool:
    """FREE -> BOOKED. False means somebody else booked it first."""
    get_slot(db, slot_id)
    claimed = slot_repo.change_status(db, slot_id, SlotStatus.FREE, SlotStatus.BOOKED)
    db.commit()
    return claimed


def release_slot(db: Session, slot_id: int) -> bool:
    """BOOKED -> FREE (cancel / reschedule / failed booking)."""
    get_slot(db, slot_id)
    released = slot_repo.change_status(db, slot_id, SlotStatus.BOOKED, SlotStatus.FREE)
    db.commit()
    return released
