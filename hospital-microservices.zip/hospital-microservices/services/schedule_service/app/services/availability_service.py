from datetime import date, datetime, timedelta

from sqlalchemy.orm import Session

from services.schedule_service.app.repositories import availability_repo
from services.schedule_service.app.schemas.availability import AvailabilityCreate
from shared import audit
from shared.client import call
from shared.dependencies import CurrentUser
from shared.exceptions import BadRequestError, ConflictError, NotFoundError


def get_my_doctor_id(user: CurrentUser) -> int:
    """Doctor profiles live in the doctor service: ask it which doctor this account is."""
    return call("doctor", "GET", f"/internal/doctors/by-user/{user.id}")["id"]


def add_template(db: Session, user: CurrentUser, data: AvailabilityCreate):
    """Story 7."""
    doctor_id = get_my_doctor_id(user)
    window = datetime.combine(date.today(), data.end_time) - datetime.combine(date.today(), data.start_time)
    if window < timedelta(minutes=data.slot_minutes):
        raise BadRequestError("The time window is shorter than one slot")
    for existing in availability_repo.list_for_doctor(db, doctor_id, data.weekday):
        if data.start_time < existing.end_time and data.end_time > existing.start_time:
            raise ConflictError("This time window overlaps an existing availability on the same weekday")
    template = availability_repo.create(db, doctor_id, data.weekday, data.start_time,
                                        data.end_time, data.slot_minutes)
    db.commit()
    audit.record(user, "AVAILABILITY_ADDED", "availability", template.id, f"doctor_id={doctor_id}")
    return template


def list_templates(db: Session, user: CurrentUser):
    return availability_repo.list_for_doctor(db, get_my_doctor_id(user))


def delete_template(db: Session, user: CurrentUser, availability_id: int) -> None:
    """Remove one of my weekly windows. Slots that were already generated from it are left as they are
    (block them if you do not want them booked)."""
    doctor_id = get_my_doctor_id(user)
    template = availability_repo.get_by_id(db, availability_id)
    if template is None or template.doctor_id != doctor_id:
        raise NotFoundError("Availability not found")
    availability_repo.delete(db, template)
    db.commit()
    audit.record(user, "AVAILABILITY_DELETED", "availability", availability_id, f"doctor_id={doctor_id}")
