from datetime import time

from sqlalchemy import select
from sqlalchemy.orm import Session

from services.schedule_service.app.models.availability_template import AvailabilityTemplate


def create(db: Session, doctor_id: int, weekday: int, start_time: time, end_time: time,
           slot_minutes: int) -> AvailabilityTemplate:
    template = AvailabilityTemplate(doctor_id=doctor_id, weekday=weekday, start_time=start_time,
                                    end_time=end_time, slot_minutes=slot_minutes)
    db.add(template)
    db.flush()
    return template


def list_for_doctor(db: Session, doctor_id: int, weekday: int | None = None) -> list[AvailabilityTemplate]:
    query = select(AvailabilityTemplate).where(AvailabilityTemplate.doctor_id == doctor_id)
    if weekday is not None:
        query = query.where(AvailabilityTemplate.weekday == weekday)
    return list(db.scalars(query.order_by(AvailabilityTemplate.weekday, AvailabilityTemplate.start_time)))


def get_by_id(db: Session, availability_id: int) -> AvailabilityTemplate | None:
    return db.get(AvailabilityTemplate, availability_id)


def delete(db: Session, template: AvailabilityTemplate) -> None:
    db.delete(template)
    db.flush()
