from datetime import date
from typing import Optional

from sqlalchemy import func, select, update
from sqlalchemy.orm import Session

from services.schedule_service.app.models.slot import Slot
from shared.enums import SlotStatus


def get_by_id(db: Session, slot_id: int) -> Optional[Slot]:
    return db.get(Slot, slot_id)


def list_for_doctor_on_date(db: Session, doctor_id: int, slot_date: date,
                            status: Optional[str] = None) -> list[Slot]:
    query = select(Slot).where(Slot.doctor_id == doctor_id, Slot.slot_date == slot_date)
    if status:
        query = query.where(Slot.status == status)
    return list(db.scalars(query.order_by(Slot.start_time)))


def list_in_range(db: Session, doctor_id: int, from_date: date, to_date: date) -> list[Slot]:
    return list(db.scalars(select(Slot).where(
        Slot.doctor_id == doctor_id, Slot.slot_date >= from_date, Slot.slot_date <= to_date)))


def add_many(db: Session, slots: list[Slot]) -> None:
    db.add_all(slots)
    db.flush()


def change_status(db: Session, slot_id: int, from_status: SlotStatus, to_status: SlotStatus) -> bool:
    """Compare-and-set in ONE statement: only one caller can move a slot out of `from_status`."""
    result = db.execute(update(Slot).where(Slot.id == slot_id, Slot.status == from_status.value)
                        .values(status=to_status.value).execution_options(synchronize_session=False))
    return result.rowcount == 1


def block_free_slots_on_date(db: Session, doctor_id: int, slot_date: date) -> int:
    result = db.execute(update(Slot).where(
        Slot.doctor_id == doctor_id, Slot.slot_date == slot_date, Slot.status == SlotStatus.FREE.value)
        .values(status=SlotStatus.BLOCKED.value).execution_options(synchronize_session=False))
    return result.rowcount


def count_booked_on_date(db: Session, doctor_id: int, slot_date: date) -> int:
    return db.scalar(select(func.count(Slot.id)).where(
        Slot.doctor_id == doctor_id, Slot.slot_date == slot_date, Slot.status == SlotStatus.BOOKED.value))
