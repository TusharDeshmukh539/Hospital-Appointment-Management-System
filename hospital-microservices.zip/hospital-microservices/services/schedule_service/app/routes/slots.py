from datetime import date

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from services.schedule_service.app.database import get_db
from services.schedule_service.app.schemas.slot import SlotOut
from services.schedule_service.app.services import slot_service
from shared.dependencies import CurrentUser, get_current_user, require_role
from shared.enums import Role

router = APIRouter(tags=["Slots"])


@router.patch("/slots/{slot_id}/block", response_model=SlotOut, summary="Block one of my free slots (DOCTOR)")
def block_slot(slot_id: int, db: Session = Depends(get_db),
               user: CurrentUser = Depends(require_role(Role.DOCTOR))):
    return slot_service.block_slot(db, user, slot_id)


@router.patch("/slots/{slot_id}/unblock", response_model=SlotOut, summary="Unblock one of my blocked slots (DOCTOR)")
def unblock_slot(slot_id: int, db: Session = Depends(get_db),
                 user: CurrentUser = Depends(require_role(Role.DOCTOR))):
    return slot_service.unblock_slot(db, user, slot_id)


@router.get("/doctors/{doctor_id}/slots", response_model=list[SlotOut],
            summary="A doctor's free slots on a date")
def free_slots(doctor_id: int, slot_date: date = Query(..., alias="date"),
               db: Session = Depends(get_db), _=Depends(get_current_user)):
    return slot_service.list_free_slots(db, doctor_id, slot_date)
