"""Called by the appointment service only (the gateway does not route /internal)."""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from services.schedule_service.app.database import get_db
from services.schedule_service.app.schemas.slot import SlotOut
from services.schedule_service.app.services import slot_service
from shared.dependencies import require_internal_key

router = APIRouter(prefix="/internal/slots", include_in_schema=False, dependencies=[Depends(require_internal_key)])


@router.get("/{slot_id}", response_model=SlotOut)
def get_slot(slot_id: int, db: Session = Depends(get_db)):
    return slot_service.get_slot(db, slot_id)


@router.post("/{slot_id}/claim")
def claim_slot(slot_id: int, db: Session = Depends(get_db)):
    return {"claimed": slot_service.claim_slot(db, slot_id)}


@router.post("/{slot_id}/release")
def release_slot(slot_id: int, db: Session = Depends(get_db)):
    return {"released": slot_service.release_slot(db, slot_id)}
