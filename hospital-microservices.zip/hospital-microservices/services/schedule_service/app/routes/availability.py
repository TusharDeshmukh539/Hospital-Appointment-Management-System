"""Everything a doctor does to their own calendar: /doctors/me/..."""
from datetime import date

from fastapi import APIRouter, Depends, Query, Response
from sqlalchemy.orm import Session

from services.schedule_service.app.database import get_db
from services.schedule_service.app.schemas.availability import (
    AvailabilityCreate, AvailabilityOut, BlockDateRequest, BlockDateResult,
    SlotGenerateRequest, SlotGenerateResult)
from services.schedule_service.app.schemas.slot import SlotOut
from services.schedule_service.app.services import availability_service, slot_service
from shared.dependencies import CurrentUser, require_role
from shared.enums import Role

router = APIRouter(prefix="/doctors/me", tags=["Doctor availability & slots"])
doctor_only = require_role(Role.DOCTOR)


@router.post("/availability", response_model=AvailabilityOut, status_code=201,
             summary="Define a weekly availability window")
def add_availability(data: AvailabilityCreate, db: Session = Depends(get_db),
                     user: CurrentUser = Depends(doctor_only)):
    return availability_service.add_template(db, user, data)


@router.get("/availability", response_model=list[AvailabilityOut], summary="List my weekly availability")
def list_availability(db: Session = Depends(get_db), user: CurrentUser = Depends(doctor_only)):
    return availability_service.list_templates(db, user)


@router.delete("/availability/{availability_id}", status_code=204, summary="Delete a weekly availability window")
def delete_availability(availability_id: int, db: Session = Depends(get_db),
                        user: CurrentUser = Depends(doctor_only)):
    availability_service.delete_template(db, user, availability_id)
    return Response(status_code=204)


@router.post("/slots/generate", response_model=SlotGenerateResult,
             summary="Generate slots from my weekly availability for a date range")
def generate_slots(data: SlotGenerateRequest, db: Session = Depends(get_db),
                   user: CurrentUser = Depends(doctor_only)):
    return slot_service.generate_slots(db, user, data)


@router.get("/slots", response_model=list[SlotOut], summary="My slots (all statuses) on a date")
def list_my_slots(slot_date: date = Query(..., alias="date"), db: Session = Depends(get_db),
                  user: CurrentUser = Depends(doctor_only)):
    return slot_service.list_my_slots(db, user, slot_date)


@router.post("/slots/block-date", response_model=BlockDateResult,
             summary="Block all my free slots on a date")
def block_date(data: BlockDateRequest, db: Session = Depends(get_db),
               user: CurrentUser = Depends(doctor_only)):
    return slot_service.block_date(db, user, data)
