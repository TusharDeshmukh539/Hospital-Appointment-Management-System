from datetime import date, datetime, time

from pydantic import BaseModel, ConfigDict


class SlotOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    doctor_id: int
    slot_date: date
    start_time: time
    end_time: time
    status: str
    created_at: datetime
    updated_at: datetime
