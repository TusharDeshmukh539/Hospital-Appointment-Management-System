from datetime import date, datetime, time, timedelta

from pydantic import BaseModel, ConfigDict, Field, model_validator

MAX_GENERATE_DAYS = 60


class AvailabilityCreate(BaseModel):
    weekday: int = Field(ge=0, le=6, description="Monday = 0 ... Sunday = 6")
    start_time: time
    end_time: time
    slot_minutes: int = Field(default=30, ge=5, le=240)

    @model_validator(mode="after")
    def check_times(self):
        if self.end_time <= self.start_time:
            raise ValueError("end_time must be later than start_time")
        return self


class AvailabilityOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    doctor_id: int
    weekday: int
    start_time: time
    end_time: time
    slot_minutes: int
    created_at: datetime
    updated_at: datetime


class SlotGenerateRequest(BaseModel):
    from_date: date
    to_date: date

    @model_validator(mode="after")
    def check_range(self):
        if self.to_date < self.from_date:
            raise ValueError("to_date must not be before from_date")
        if (self.to_date - self.from_date) > timedelta(days=MAX_GENERATE_DAYS - 1):
            raise ValueError(f"date range can be at most {MAX_GENERATE_DAYS} days")
        return self


class SlotGenerateResult(BaseModel):
    created: int
    skipped: int


class BlockDateRequest(BaseModel):
    slot_date: date


class BlockDateResult(BaseModel):
    blocked: int
    already_booked: int
