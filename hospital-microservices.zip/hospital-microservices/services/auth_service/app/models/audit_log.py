from datetime import datetime
from typing import Optional

from sqlalchemy import DateTime, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from services.auth_service.app.database import Base
from shared.models import utc_now


class AuditLog(Base):
    """One row per important action: who (user_id) did what (action) to which record (entity, entity_id)."""

    __tablename__ = "audit_logs"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[Optional[int]] = mapped_column(Integer, index=True)  # None = nobody logged in (e.g. failed login)
    action: Mapped[str] = mapped_column(String(50), index=True)  # e.g. LOGIN_FAILED, APPOINTMENT_BOOKED
    entity: Mapped[Optional[str]] = mapped_column(String(50))  # e.g. "appointment"
    entity_id: Mapped[Optional[int]] = mapped_column(Integer)
    detail: Mapped[Optional[str]] = mapped_column(String(255))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now, index=True)
