from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from services.auth_service.app.database import get_db
from services.auth_service.app.schemas.user import UserOut
from services.auth_service.app.services import auth_service
from shared.dependencies import CurrentUser, require_role
from shared.enums import Role

router = APIRouter(prefix="/users", tags=["Users (admin)"])


@router.patch("/{user_id}/activate", response_model=UserOut, summary="Re-activate a user (ADMIN)")
def activate_user(user_id: int, db: Session = Depends(get_db),
                  admin: CurrentUser = Depends(require_role(Role.ADMIN))):
    return auth_service.activate_user(db, admin, user_id)


@router.patch("/{user_id}/deactivate", response_model=UserOut, summary="Deactivate a user (ADMIN)")
def deactivate_user(user_id: int, db: Session = Depends(get_db),
                    admin: CurrentUser = Depends(require_role(Role.ADMIN))):
    return auth_service.deactivate_user(db, admin, user_id)
