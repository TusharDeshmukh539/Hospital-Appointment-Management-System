from fastapi import APIRouter, Depends
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from services.auth_service.app.database import get_db
from services.auth_service.app.schemas.auth import RegisterRequest, TokenResponse
from services.auth_service.app.schemas.user import UserOut
from services.auth_service.app.services import auth_service

router = APIRouter(prefix="/auth", tags=["Auth"])


@router.post("/register", response_model=UserOut, status_code=201, summary="Register as a patient")
def register(data: RegisterRequest, db: Session = Depends(get_db)):
    return auth_service.register_patient(db, data)


@router.post("/login", response_model=TokenResponse, summary="Log in and get a JWT")
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    return auth_service.login(db, form.username, form.password)
