"""Called by the gateway and the other services only (the gateway does not route /internal)."""
from fastapi import APIRouter, Depends, Response
from sqlalchemy.orm import Session

from services.auth_service.app.database import get_db
from services.auth_service.app.schemas.audit import AuditCreate
from services.auth_service.app.schemas.user import InternalUserCreate, InternalUserUpdate, UserOut
from services.auth_service.app.services import audit_service, auth_service
from shared.dependencies import require_internal_key

router = APIRouter(prefix="/internal/users", include_in_schema=False, dependencies=[Depends(require_internal_key)])
audit_router = APIRouter(prefix="/internal/audit", include_in_schema=False,
                         dependencies=[Depends(require_internal_key)])


@router.post("", response_model=UserOut, status_code=201)
def create_user(data: InternalUserCreate, db: Session = Depends(get_db)):
    return auth_service.create_user(db, data)


@router.get("/{user_id}", response_model=UserOut)
def get_user(user_id: int, db: Session = Depends(get_db)):
    return auth_service.get_user(db, user_id)


@router.patch("/{user_id}", response_model=UserOut)
def update_user(user_id: int, data: InternalUserUpdate, db: Session = Depends(get_db)):
    return auth_service.update_user(db, user_id, data)


@router.delete("/{user_id}", status_code=204)
def delete_user(user_id: int, db: Session = Depends(get_db)):
    auth_service.delete_user(db, user_id)
    return Response(status_code=204)


@audit_router.post("", status_code=204)
def add_audit_entry(data: AuditCreate, db: Session = Depends(get_db)):
    audit_service.record(db, **data.model_dump())
    db.commit()
    return Response(status_code=204)
