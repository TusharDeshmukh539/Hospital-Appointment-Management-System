from typing import Literal, Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from services.auth_service.app.database import get_db
from services.auth_service.app.schemas.audit import AuditOut
from services.auth_service.app.services import audit_service
from shared.dependencies import require_role
from shared.enums import Role
from shared.pagination import Page, SortOrder

router = APIRouter(prefix="/audit-logs", tags=["Audit log (admin)"])


@router.get("", response_model=Page[AuditOut], summary="Audit trail, newest first (ADMIN)")
def list_audit_logs(user_id: Optional[int] = Query(None, description="Only actions done by this user"),
                    action: Optional[str] = Query(None, max_length=50, description="e.g. LOGIN_FAILED"),
                    sort_by: Literal["created_at", "action", "user_id"] = "created_at",
                    order: Optional[SortOrder] = Query(None, description="Defaults to desc"),
                    page: int = Query(1, ge=1), size: int = Query(10, ge=1, le=100),
                    db: Session = Depends(get_db), _=Depends(require_role(Role.ADMIN))):
    return audit_service.list_entries(db, user_id, action, sort_by, order, page, size)
