from sqlalchemy.orm import Session

from services.auth_service.app.repositories import user_repo
from services.auth_service.app.schemas.auth import RegisterRequest
from services.auth_service.app.schemas.user import InternalUserCreate, InternalUserUpdate
from services.auth_service.app.services import audit_service
from shared.client import call
from shared.dependencies import CurrentUser
from shared.enums import Role
from shared.exceptions import (
    ConflictError, ForbiddenError, NotFoundError, TooManyRequestsError, UnauthorizedError)
from shared.rate_limit import login_limiter
from shared.security import create_access_token, hash_password, verify_password


def register_patient(db: Session, data: RegisterRequest):
    """Story 1: create the login account here, the patient profile in the patient service."""
    if user_repo.get_by_email(db, data.email):
        raise ConflictError("An account with this email already exists")
    user = user_repo.create(db, data.email, hash_password(data.password), data.full_name,
                            data.phone, Role.PATIENT.value)
    db.commit()
    try:
        call("patient", "POST", "/internal/patients", json={
            "user_id": user.id, "full_name": user.full_name, "email": user.email, "phone": user.phone})
    except Exception:  # the two databases cannot share a transaction, so undo the account
        user_repo.delete(db, user)
        db.commit()
        raise
    audit_service.record(db, user.id, "USER_REGISTERED", "user", user.id)
    db.commit()
    return user


def login(db: Session, email: str, password: str) -> dict:
    """Story 3. Too many wrong passwords for one email -> 429 for a while (see LOGIN_MAX_ATTEMPTS)."""
    key = email.lower()
    try:
        login_limiter.check(key)
    except TooManyRequestsError:
        audit_service.record(db, None, "LOGIN_RATE_LIMITED", "user", detail=f"email={key}")
        db.commit()
        raise
    user = user_repo.get_by_email(db, email)
    if user is None or not verify_password(password, user.password_hash):
        login_limiter.hit(key)
        audit_service.record(db, user.id if user else None, "LOGIN_FAILED", "user",
                             user.id if user else None, detail=f"email={key}")
        db.commit()
        raise UnauthorizedError("Incorrect email or password")
    if not user.is_active:
        audit_service.record(db, user.id, "LOGIN_REFUSED_INACTIVE", "user", user.id)
        db.commit()
        raise ForbiddenError("This account has been deactivated")
    login_limiter.reset(key)
    audit_service.record(db, user.id, "LOGIN_SUCCESS", "user", user.id)
    db.commit()
    return {"access_token": create_access_token(user.id, user.role), "token_type": "bearer"}


def _set_active(db: Session, admin: CurrentUser, user_id: int, is_active: bool):
    """Shared by stories 4 (deactivate) and activate: the doctor service shows/hides doctors in searches."""
    user = get_user(db, user_id)
    user.is_active = is_active
    if user.role == Role.DOCTOR.value:
        try:
            call("doctor", "PATCH", f"/internal/doctors/by-user/{user.id}/active", json={"is_active": is_active})
        except NotFoundError:
            pass
        except Exception:
            db.rollback()
            raise
    audit_service.record(db, admin.id, "USER_ACTIVATED" if is_active else "USER_DEACTIVATED", "user", user.id)
    db.commit()
    return user


def deactivate_user(db: Session, admin: CurrentUser, user_id: int):
    """Story 4."""
    if user_id == admin.id:
        raise ConflictError("You cannot deactivate your own account")
    return _set_active(db, admin, user_id, False)


def activate_user(db: Session, admin: CurrentUser, user_id: int):
    """Undo story 4: the account can log in again (and a doctor shows up in searches again)."""
    return _set_active(db, admin, user_id, True)


# ---- used by the other services ----

def get_user(db: Session, user_id: int):
    user = user_repo.get_by_id(db, user_id)
    if user is None:
        raise NotFoundError("User not found")
    return user


def create_user(db: Session, data: InternalUserCreate):
    if user_repo.get_by_email(db, data.email):
        raise ConflictError("An account with this email already exists")
    user = user_repo.create(db, data.email, hash_password(data.password), data.full_name,
                            data.phone, data.role)
    db.commit()
    return user


def update_user(db: Session, user_id: int, data: InternalUserUpdate):
    user = get_user(db, user_id)
    for field, value in data.model_dump(exclude_unset=True).items():
        setattr(user, field, value)
    db.commit()
    return user


def delete_user(db: Session, user_id: int) -> None:
    user_repo.delete(db, get_user(db, user_id))
    db.commit()
