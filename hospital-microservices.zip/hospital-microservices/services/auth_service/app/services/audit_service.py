from typing import Optional

from sqlalchemy.orm import Session

from services.auth_service.app.repositories import audit_repo


def record(db: Session, user_id: Optional[int], action: str, entity: Optional[str] = None,
           entity_id: Optional[int] = None, detail: Optional[str] = None):
    """Add an audit row to the current transaction (the caller commits)."""
    return audit_repo.add(db, user_id, action, entity, entity_id, detail)


def list_entries(db: Session, user_id: Optional[int], action: Optional[str], sort_by: str,
                 order: Optional[str], page: int, size: int) -> dict:
    return audit_repo.search(db, user_id, action, sort_by, order, page, size)
