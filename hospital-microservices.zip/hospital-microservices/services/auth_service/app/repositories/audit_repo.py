from typing import Optional

from sqlalchemy import select
from sqlalchemy.orm import Session

from services.auth_service.app.models.audit_log import AuditLog
from shared.pagination import paginate, sort_clauses

SORTABLE = {"created_at": [AuditLog.created_at, AuditLog.id], "action": [AuditLog.action, AuditLog.id],
            "user_id": [AuditLog.user_id, AuditLog.id]}


def add(db: Session, user_id: Optional[int], action: str, entity: Optional[str],
        entity_id: Optional[int], detail: Optional[str]) -> AuditLog:
    entry = AuditLog(user_id=user_id, action=action, entity=entity, entity_id=entity_id,
                     detail=detail[:255] if detail else None)
    db.add(entry)
    db.flush()
    return entry


def search(db: Session, user_id: Optional[int], action: Optional[str], sort_by: str, order: Optional[str],
           page: int, size: int) -> dict:
    query = select(AuditLog)
    if user_id is not None:
        query = query.where(AuditLog.user_id == user_id)
    if action:
        query = query.where(AuditLog.action == action.upper())
    return paginate(db, query.order_by(*sort_clauses(SORTABLE, sort_by, order, "created_at", "desc")), page, size)
