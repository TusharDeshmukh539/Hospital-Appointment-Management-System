from typing import Optional

from pydantic import BaseModel, EmailStr, Field, field_validator

from shared.security import check_password_strength


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)
    full_name: str = Field(min_length=2, max_length=100)
    phone: Optional[str] = Field(default=None, pattern=r"^\+?[0-9]{10,13}$")

    @field_validator("email")
    @classmethod
    def lowercase_email(cls, value: str) -> str:
        return value.lower()

    @field_validator("password")
    @classmethod
    def strong_password(cls, value: str) -> str:
        return check_password_strength(value)


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
