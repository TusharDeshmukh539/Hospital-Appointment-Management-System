from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict


class AuditOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    user_id: Optional[int]
    action: str
    entity: Optional[str]
    entity_id: Optional[int]
    detail: Optional[str]
    created_at: datetime


# Used only by other services (internal API)
class AuditCreate(BaseModel):
    user_id: Optional[int] = None
    action: str
    entity: Optional[str] = None
    entity_id: Optional[int] = None
    detail: Optional[str] = None
