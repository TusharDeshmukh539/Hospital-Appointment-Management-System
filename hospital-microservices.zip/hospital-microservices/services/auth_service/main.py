"""Auth service: accounts, login, (de)activation, audit trail. Database: AUTH_DATABASE_URL (tables: users, audit_logs)."""
from fastapi import FastAPI

from services.auth_service.app import models  # noqa: F401
from services.auth_service.app.routes import audit, auth, internal, users
from shared.exceptions import add_error_handlers

app = FastAPI(title="Auth service", docs_url=None, redoc_url=None, openapi_url=None)
add_error_handlers(app)
app.include_router(auth.router)
app.include_router(users.router)
app.include_router(audit.router)
app.include_router(internal.router)
app.include_router(internal.audit_router)
