import re

import httpx
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi
from fastapi.responses import Response

from services.appointment_service.main import app as appointment_app
from services.auth_service.main import app as auth_app
from services.doctor_service.main import app as doctor_app
from services.patient_service.main import app as patient_app
from services.schedule_service.main import app as schedule_app
from shared import client
from shared.config import settings
from shared.exceptions import NotFoundError, ServiceUnavailableError, UnauthorizedError, add_error_handlers
from shared.security import decode_access_token

SERVICES = {"auth": auth_app, "doctor": doctor_app, "patient": patient_app,
            "schedule": schedule_app, "appointment": appointment_app}
client.apps.update(SERVICES)  # lets the services call each other

# URL -> owning service (first match wins). /internal/... is deliberately not listed.
ROUTES = [
    (r"^/doctors/me/(availability|slots)(/|$)", "schedule"),
    (r"^/doctors/[^/]+/slots$", "schedule"),
    (r"^/slots(/|$)", "schedule"),
    (r"^/(doctors|specialities)(/|$)", "doctor"),
    (r"^/(auth|users|audit-logs)(/|$)", "auth"),
    (r"^/patients(/|$)", "patient"),
    (r"^/(appointments|consultations)(/|$)", "appointment"),
    (r"^/admin/reports(/|$)", "appointment"),
]

PUBLIC = {("POST", "/auth/register"), ("POST", "/auth/login")}  # no token needed

app = FastAPI(title="Hospital Appointment Management API", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=[o.strip() for o in settings.CORS_ORIGINS.split(",")],
                   allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
add_error_handlers(app)


async def send(service: str, method: str, url: str, headers: dict | None = None, body: bytes | None = None):
    transport = httpx.ASGITransport(app=SERVICES[service], raise_app_exceptions=False)
    async with httpx.AsyncClient(transport=transport, base_url="http://service") as http:
        return await http.request(method, url, headers=headers, content=body)


async def authenticate(request: Request) -> dict:
    """Valid JWT + account still active in the auth service -> {"id": ..., "role": ...}."""
    scheme, _, token = request.headers.get("authorization", "").partition(" ")
    if scheme.lower() != "bearer" or not token:
        raise UnauthorizedError()
    try:
        user_id = int(decode_access_token(token)["sub"])
    except (KeyError, ValueError):
        raise UnauthorizedError("Invalid or expired token")
    response = await send("auth", "GET", f"/internal/users/{user_id}",
                          headers={"x-internal-key": settings.INTERNAL_API_KEY})
    if response.status_code == 404:
        raise UnauthorizedError("Invalid or expired token")
    if response.status_code != 200:
        raise ServiceUnavailableError()
    user = response.json()
    if not user["is_active"]:
        raise UnauthorizedError("Invalid or expired token")
    return user


@app.get("/health", include_in_schema=False)
def health():
    return {"status": "ok"}


@app.api_route("/{path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE"], include_in_schema=False)
async def proxy(request: Request, path: str):
    path = "/" + path
    service = next((name for pattern, name in ROUTES if re.match(pattern, path)), None)
    if service is None:
        raise NotFoundError("Not found")

    headers = {}  # only these headers are forwarded, so clients cannot fake the identity ones
    if "content-type" in request.headers:
        headers["content-type"] = request.headers["content-type"]
    if (request.method, path.rstrip("/")) not in PUBLIC:
        user = await authenticate(request)
        headers["x-user-id"], headers["x-user-role"] = str(user["id"]), user["role"]

    url = path + (f"?{request.url.query}" if request.url.query else "")
    response = await send(service, request.method, url, headers, await request.body())
    return Response(response.content, status_code=response.status_code,
                    media_type=response.headers.get("content-type"))


def custom_openapi():
    """One Swagger page for all services, with the Authorize button for the JWT."""
    if app.openapi_schema is None:
        schema = get_openapi(title=app.title, version=app.version, routes=[])
        schema["components"] = {"schemas": {}, "securitySchemes": {
            "OAuth2PasswordBearer": {"type": "oauth2", "flows": {"password": {"tokenUrl": "/auth/login", "scopes": {}}}}}}
        for service_app in SERVICES.values():
            part = service_app.openapi()
            schema["paths"].update(part["paths"])
            schema["components"]["schemas"].update(part.get("components", {}).get("schemas", {}))
        for path, operations in schema["paths"].items():
            for method, operation in operations.items():
                if (method.upper(), path) not in PUBLIC:
                    operation["security"] = [{"OAuth2PasswordBearer": []}]
        app.openapi_schema = schema
    return app.openapi_schema


app.openapi = custom_openapi
