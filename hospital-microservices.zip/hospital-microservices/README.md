# Hospital Appointment Management System (Microservices)

Five microservices, each with **its own database**, behind one **API gateway** that runs on a single uvicorn.

```
client ──► gateway (JWT check + routing) ──► auth · doctor · patient · schedule · appointment
                                              │       │        │         │            │
                                           auth_db doctor_db patient_db schedule_db appointment_db
```

| Service | Database tables | User stories |
|---|---|---|
| `auth_service` | users, audit_logs | 1 register, 3 login (JWT, rate limited), 4 deactivate user, activate user, audit log |
| `doctor_service` | specialities, doctors | 2 create doctor, 5 specialities, 6 doctor profile, 9 search doctors, view one doctor |
| `patient_service` | patients | 11 view profile, 12 update profile, admin patient list |
| `schedule_service` | availability_templates, slots | 7 weekly availability + slot generation, 8 block slot/date, 10 free slots, unblock slot, delete availability |
| `appointment_service` | appointments, consultations | 13 book, 14 reschedule, 15 cancel, 16 my appointments, 17 doctor's day, 18 completed/no-show, 19 record consultation, 20 consultation history, view one consultation, admin reports |

## Added features

| Feature | Endpoint | Who |
|---|---|---|
| Admin patient list (`q`, sorting, paging) | `GET /patients` | ADMIN |
| Admin report: appointments per status and doctor (`from_date`, `to_date`) | `GET /admin/reports/appointments` | ADMIN |
| Unblock a slot | `PATCH /slots/{id}/unblock` | DOCTOR |
| Delete a weekly availability window (generated slots stay) | `DELETE /doctors/me/availability/{id}` | DOCTOR |
| Activate a user again (a doctor reappears in searches) | `PATCH /users/{id}/activate` | ADMIN |
| View one doctor (deactivated ones are 404 except for admins) | `GET /doctors/{id}` | any user |
| View one consultation (its patient or its doctor only) | `GET /consultations/{id}` | PATIENT, DOCTOR |
| Audit trail (`user_id`, `action`, sorting, paging) | `GET /audit-logs` | ADMIN |

* **Login rate limit** - after `LOGIN_MAX_ATTEMPTS` (5) wrong passwords for one email within
  `LOGIN_WINDOW_SECONDS` (300) login answers `429`; a successful login resets the counter. The counters are kept in memory
  (`shared/rate_limit.py`), which fits the single-uvicorn setup.
* **Audit logging** - logins (success, failure, rate limited), registration, user (de)activation, doctor and speciality
  changes, availability and slot changes, appointments and consultations. Every service calls `shared/audit.record(...)`
  after its action succeeded; the rows are stored by the auth service in `audit_logs`. It is best effort: if storing fails,
  the real action still succeeds (the failure is logged).
* **Internal key** - every `/internal/*` endpoint requires the `x-internal-key` header to equal `INTERNAL_API_KEY`
  (`shared.dependencies.require_internal_key`). `shared/client.py` and the gateway add it for you.
* **Timestamps** - every table has `created_at` and `updated_at` (`shared/models.py` `TimestampMixin`), returned by the API.
* **Sorting** - the paginated lists accept `sort_by` and `order` (`asc` / `desc`): doctors (`full_name`, `experience_years`,
  `consultation_fee`), specialities, my appointments, a doctor's day, consultations, patients and audit logs. The defaults
  are the old orders. See `shared/pagination.py` `sort_clauses`.

## Structure

```
gateway/main.py              single entry point (routing, JWT check, merged Swagger)
shared/                      config, security (JWT/bcrypt), exceptions, dependencies, service-to-service client, pagination + sorting, enums,
                             models (timestamps), rate_limit, audit
services/<name>_service/
    main.py                  the service's FastAPI app
    app/
        database.py          this service's own engine / session / Base
        models/  schemas/  repositories/  services/  routes/
    alembic.ini, alembic/    this service's own migrations (empty, you generate them)
scripts/create_admin.py      first admin account
tests/test_user_stories.py   one test per user story
```

## How the pieces work together

* The **gateway** maps each URL to its service, checks the JWT (and that the account is still active),
  and passes `x-user-id` / `x-user-role` to the service. Services use these for role checks.
  `/internal/*` endpoints (service to service) are not reachable through the gateway.
* There are **no foreign keys between databases**; other services' ids (`user_id`, `doctor_id`,
  `patient_id`, `slot_id`) are plain integer columns. Names are copied where needed
  (doctors/patients keep `full_name`, appointments keep doctor/patient names and the slot date/time).
* One action that touched several tables is now several steps with an undo:
  * register / create doctor: account first, profile second; the account is deleted if the profile fails
  * book: the slot is claimed atomically (`FREE -> BOOKED`) in the schedule service, then the appointment
    is saved; the slot is released if saving fails
  * deactivate doctor: the doctor service is told so the doctor disappears from searches

## Run

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env            # 5 database URLs + JWT_SECRET_KEY + INTERNAL_API_KEY
```

Create the five empty databases, then run the migrations of each service (from the project root):

```bash
alembic -c services/auth_service/alembic.ini revision --autogenerate -m "init"
alembic -c services/auth_service/alembic.ini upgrade head
# same for doctor_service, patient_service, schedule_service, appointment_service
# (the new columns/tables - timestamps and audit_logs - are picked up by --autogenerate)
python -m scripts.create_admin admin@example.com 'Admin123!' "Admin User"
uvicorn gateway.main:app --reload       # Swagger: http://localhost:8000/docs
```

## Test

```bash
pytest
```
