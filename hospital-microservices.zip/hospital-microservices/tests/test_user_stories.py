"""One test per user story (numbers match the story list), all through the API gateway."""
from datetime import date, datetime, timedelta, timezone

from services.appointment_service.app.database import SessionLocal as AppointmentSession
from services.appointment_service.app.models import Appointment
from services.auth_service.app.database import SessionLocal as AuthSession
from services.auth_service.app.models import User
from services.patient_service.app.database import SessionLocal as PatientSession
from services.patient_service.app.models import Patient
from services.schedule_service.app.database import SessionLocal as ScheduleSession
from services.schedule_service.app.models import Slot
from tests.conftest import login

DAY = date.today() + timedelta(days=7)


def make_slots(client, doctor, minutes=30):
    """Doctor works 09:00-10:00 on DAY's weekday -> two slots; returns their ids."""
    client.post("/doctors/me/availability", headers=doctor["headers"], json={
        "weekday": DAY.weekday(), "start_time": "09:00:00", "end_time": "10:00:00", "slot_minutes": minutes})
    client.post("/doctors/me/slots/generate", headers=doctor["headers"],
                json={"from_date": str(DAY), "to_date": str(DAY)})
    slots = client.get("/doctors/me/slots", headers=doctor["headers"], params={"date": str(DAY)}).json()
    return [s["id"] for s in slots]


def book(client, patient, slot_id):
    return client.post("/appointments", headers=patient, json={"slot_id": slot_id, "reason": "Checkup"})


def slot_status(slot_id):
    with ScheduleSession() as db:
        return db.get(Slot, slot_id).status


# ------------------------------------------------------------------ accounts
def test_1_visitor_registers_as_patient(client):
    response = client.post("/auth/register", json={"email": "New@Test.com", "password": "Password123",
                                                   "full_name": "New Patient", "phone": "5555555555"})
    assert response.status_code == 201
    assert response.json()["role"] == "PATIENT" and response.json()["email"] == "new@test.com"
    with AuthSession() as db:  # the account is in the auth DB ...
        assert db.query(User).count() == 1
    with PatientSession() as db:  # ... and the profile in the patient DB
        assert db.query(Patient).count() == 1
    # duplicate email and weak password are rejected
    assert client.post("/auth/register", json={"email": "new@test.com", "password": "Password123",
                                               "full_name": "Again"}).status_code == 409
    assert client.post("/auth/register", json={"email": "x@test.com", "password": "onlyletters",
                                               "full_name": "Weak"}).status_code == 422


def test_1_registration_is_undone_if_the_patient_service_fails(client, monkeypatch):
    from services.auth_service.app.services import auth_service

    def broken(*args, **kwargs):
        raise RuntimeError("patient service down")

    monkeypatch.setattr(auth_service, "call", broken)
    quiet = type(client)(client.app, raise_server_exceptions=False)
    assert quiet.post("/auth/register", json={"email": "ghost@test.com", "password": "Password123",
                                              "full_name": "Ghost"}).status_code == 500
    with AuthSession() as db:
        assert db.query(User).count() == 0


def test_2_admin_creates_a_doctor_account(client, admin, speciality, patient):
    body = {"email": "doc@test.com", "password": "Password123", "full_name": "Dr. New",
            "speciality_id": speciality["id"], "registration_no": "REG-9", "qualification": "MBBS",
            "experience_years": 4, "consultation_fee": "300"}
    created = client.post("/doctors", headers=admin, json=body)
    assert created.status_code == 201 and created.json()["speciality_name"] == "Cardiology"
    login(client, "doc@test.com", "Password123")  # the doctor can log in
    # only admins, no duplicates, speciality must exist; failures leave no account behind
    assert client.post("/doctors", headers=patient, json=body).status_code == 403
    assert client.post("/doctors", headers=admin, json=body).status_code == 409
    assert client.post("/doctors", headers=admin, json={**body, "email": "d2@test.com", "speciality_id": 99}).status_code == 404
    assert client.post("/doctors", headers=admin, json={**body, "email": "d3@test.com"}).status_code == 409  # same reg. no.
    with AuthSession() as db:
        assert db.query(User).filter(User.email.in_(["d2@test.com", "d3@test.com"])).count() == 0


def test_3_login_returns_a_jwt_for_protected_endpoints(client, patient):
    assert client.get("/patients/me").status_code == 401
    assert client.get("/patients/me", headers={"Authorization": "Bearer garbage"}).status_code == 401
    assert client.get("/patients/me", headers=patient).status_code == 200
    bad = client.post("/auth/login", data={"username": "patient@test.com", "password": "wrong"})
    assert bad.status_code == 401


def test_4_admin_deactivates_a_user(client, admin, patient, doctor):
    with AuthSession() as db:
        patient_id = db.query(User).filter_by(email="patient@test.com").one().id
        doctor_user_id = db.query(User).filter_by(email="doctor@test.com").one().id
    assert client.patch(f"/users/{patient_id}/deactivate", headers=patient).status_code == 403
    assert client.patch(f"/users/{patient_id}/deactivate", headers=admin).status_code == 200
    # cannot log in any more, and the old token stops working at once
    assert client.post("/auth/login", data={"username": "patient@test.com", "password": "Password123"}).status_code == 403
    assert client.get("/patients/me", headers=patient).status_code == 401
    # a deactivated doctor also disappears from the doctor search
    assert client.get("/doctors", headers=admin).json()["total"] == 1
    client.patch(f"/users/{doctor_user_id}/deactivate", headers=admin)
    assert client.get("/doctors", headers=admin).json()["total"] == 0


# ------------------------------------------------------------- specialities / doctors
def test_5_admin_maintains_specialities(client, admin, patient):
    created = client.post("/specialities", headers=admin, json={"name": "Neurology"})
    assert created.status_code == 201
    speciality_id = created.json()["id"]
    assert client.post("/specialities", headers=admin, json={"name": "neurology"}).status_code == 409
    assert client.post("/specialities", headers=patient, json={"name": "Hacking"}).status_code == 403
    assert client.get("/specialities", headers=patient).json()["total"] == 1  # anyone logged in can list
    renamed = client.put(f"/specialities/{speciality_id}", headers=admin, json={"name": "Neuro Science"})
    assert renamed.json()["name"] == "Neuro Science"
    assert client.delete(f"/specialities/{speciality_id}", headers=admin).status_code == 204


def test_5_a_speciality_in_use_cannot_be_deleted(client, admin, doctor, speciality):
    assert client.delete(f"/specialities/{speciality['id']}", headers=admin).status_code == 409


def test_6_doctor_maintains_own_profile(client, doctor):
    updated = client.put("/doctors/me", headers=doctor["headers"],
                         json={"qualification": "MD, DM", "experience_years": 12, "consultation_fee": "650.50"})
    assert updated.status_code == 200
    profile = client.get("/doctors/me", headers=doctor["headers"]).json()
    assert (profile["qualification"], profile["experience_years"], profile["consultation_fee"]) == ("MD, DM", 12, "650.50")


def test_7_doctor_defines_weekly_availability_and_generates_slots(client, doctor):
    template = client.post("/doctors/me/availability", headers=doctor["headers"], json={
        "weekday": DAY.weekday(), "start_time": "10:00:00", "end_time": "11:00:00", "slot_minutes": 30})
    assert template.status_code == 201
    overlap = client.post("/doctors/me/availability", headers=doctor["headers"], json={
        "weekday": DAY.weekday(), "start_time": "10:30:00", "end_time": "12:00:00", "slot_minutes": 30})
    assert overlap.status_code == 409
    assert len(client.get("/doctors/me/availability", headers=doctor["headers"]).json()) == 1

    body = {"from_date": str(DAY), "to_date": str(DAY)}
    assert client.post("/doctors/me/slots/generate", headers=doctor["headers"], json=body).json() == {"created": 2, "skipped": 0}
    assert client.post("/doctors/me/slots/generate", headers=doctor["headers"], json=body).json() == {"created": 0, "skipped": 2}


def test_8_doctor_blocks_a_slot_and_a_whole_date(client, doctor, patient):
    first, second = make_slots(client, doctor)
    assert client.patch(f"/slots/{first}/block", headers=doctor["headers"]).json()["status"] == "BLOCKED"
    assert book(client, patient, first).status_code == 409  # blocked slots cannot be booked
    assert book(client, patient, second).status_code == 201
    result = client.post("/doctors/me/slots/block-date", headers=doctor["headers"], json={"slot_date": str(DAY)})
    assert result.json() == {"blocked": 0, "already_booked": 1}  # the booked slot is left alone


def test_8_block_date_blocks_all_free_slots(client, doctor, patient):
    ids = make_slots(client, doctor)
    assert client.post("/doctors/me/slots/block-date", headers=doctor["headers"],
                       json={"slot_date": str(DAY)}).json() == {"blocked": 2, "already_booked": 0}
    assert book(client, patient, ids[0]).status_code == 409


def test_9_patient_searches_doctors_with_pagination(client, admin, doctor, patient, speciality):
    neuro = client.post("/specialities", headers=admin, json={"name": "Neurology"}).json()
    for i in range(3):
        client.post("/doctors", headers=admin, json={
            "email": f"n{i}@test.com", "password": "Password123", "full_name": f"Dr. Neuro {i}",
            "speciality_id": neuro["id"], "registration_no": f"N-{i}", "qualification": "MD",
            "experience_years": 1, "consultation_fee": "100"})
    assert client.get("/doctors", headers=patient, params={"speciality": "cardio"}).json()["total"] == 1
    assert client.get("/doctors", headers=patient, params={"name": "NEURO"}).json()["total"] == 3
    page = client.get("/doctors", headers=patient, params={"page": 2, "size": 3}).json()
    assert (page["total"], page["page"], len(page["items"])) == (4, 2, 1)


# --------------------------------------------------------------- slots and patient profile
def test_10_patient_views_free_slots_of_a_doctor(client, doctor, patient):
    first, second = make_slots(client, doctor)
    book(client, patient, first)
    free = client.get(f"/doctors/{doctor['id']}/slots", headers=patient, params={"date": str(DAY)}).json()
    assert [s["id"] for s in free] == [second]
    assert client.get("/doctors/999/slots", headers=patient, params={"date": str(DAY)}).status_code == 404


def test_11_patient_views_own_profile(client, patient):
    profile = client.get("/patients/me", headers=patient).json()
    assert (profile["full_name"], profile["email"], profile["phone"]) == ("Patient One", "patient@test.com", "7777777777")


def test_12_patient_updates_own_profile(client, patient):
    response = client.put("/patients/me", headers=patient, json={
        "full_name": "Renamed Person", "phone": "5551234567", "gender": "FEMALE",
        "blood_group": "B+", "date_of_birth": "1990-05-01", "address": "12 Main Street"})
    assert response.status_code == 200 and response.json()["blood_group"] == "B+"
    with AuthSession() as db:  # name and phone are kept in the account too
        user = db.query(User).filter_by(email="patient@test.com").one()
        assert (user.full_name, user.phone) == ("Renamed Person", "5551234567")
    assert client.put("/patients/me", headers=patient, json={"blood_group": "Z"}).status_code == 422


# ----------------------------------------------------------------------- appointments
def test_13_patient_books_a_free_slot(client, doctor, patient, patient2):
    first, _ = make_slots(client, doctor)
    booked = book(client, patient, first)
    assert booked.status_code == 201
    assert (booked.json()["status"], booked.json()["doctor_name"], booked.json()["patient_name"]) == ("BOOKED", "Dr. Test", "Patient One")
    assert slot_status(first) == "BOOKED"
    assert book(client, patient2, first).status_code == 409  # the slot is taken
    assert book(client, patient, 999).status_code == 404


def test_13_one_active_booking_per_doctor_per_day(client, doctor, patient):
    first, second = make_slots(client, doctor)
    book(client, patient, first)
    assert book(client, patient, second).status_code == 409


def test_13_the_slot_is_released_if_saving_the_appointment_fails(client, doctor, patient, monkeypatch):
    from services.appointment_service.app.services import appointment_service

    def broken(*args, **kwargs):
        raise RuntimeError("database error")

    first, _ = make_slots(client, doctor)
    monkeypatch.setattr(appointment_service.appointment_repo, "create", broken)
    quiet = type(client)(client.app, raise_server_exceptions=False)
    assert quiet.post("/appointments", headers=patient, json={"slot_id": first}).status_code == 500
    assert slot_status(first) == "FREE"


def test_14_patient_reschedules_to_another_slot(client, doctor, patient):
    first, second = make_slots(client, doctor)
    appointment = book(client, patient, first).json()
    moved = client.patch(f"/appointments/{appointment['id']}/reschedule", headers=patient, json={"new_slot_id": second})
    assert moved.status_code == 200
    assert (moved.json()["slot_id"], moved.json()["start_time"]) == (second, "09:30:00")
    assert (slot_status(first), slot_status(second)) == ("FREE", "BOOKED")


def test_15_patient_cancels_before_the_cut_off(client, doctor, patient):
    first, _ = make_slots(client, doctor)
    appointment = book(client, patient, first).json()
    cancelled = client.patch(f"/appointments/{appointment['id']}/cancel", headers=patient)
    assert cancelled.status_code == 200 and cancelled.json()["status"] == "CANCELLED"
    assert slot_status(first) == "FREE"
    assert client.patch(f"/appointments/{appointment['id']}/cancel", headers=patient).status_code == 409


def test_15_cancelling_inside_the_cut_off_is_refused(client, doctor, patient):
    first, _ = make_slots(client, doctor)
    appointment = book(client, patient, first).json()
    soon = datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(minutes=30)
    with AppointmentSession() as db:  # pretend the slot starts in 30 minutes
        row = db.get(Appointment, appointment["id"])
        row.slot_date, row.start_time = soon.date(), soon.time()
        db.commit()
    assert client.patch(f"/appointments/{appointment['id']}/cancel", headers=patient).status_code == 400
    assert slot_status(first) == "BOOKED"


def test_15_only_the_owner_can_cancel(client, doctor, patient, patient2):
    first, _ = make_slots(client, doctor)
    appointment = book(client, patient, first).json()
    assert client.patch(f"/appointments/{appointment['id']}/cancel", headers=patient2).status_code == 404


def test_16_patient_views_upcoming_and_past_appointments(client, doctor, patient):
    first, second = make_slots(client, doctor)
    book(client, patient, first)
    appointments = client.get("/appointments/me", headers=patient).json()
    assert appointments["total"] == 1
    assert client.get("/appointments/me", headers=patient, params={"when": "upcoming"}).json()["total"] == 1
    assert client.get("/appointments/me", headers=patient, params={"when": "past"}).json()["total"] == 0
    appointment_id = appointments["items"][0]["id"]
    client.patch(f"/appointments/{appointment_id}/cancel", headers=patient)  # cancelled -> no longer upcoming
    assert client.get("/appointments/me", headers=patient, params={"when": "upcoming"}).json()["total"] == 0
    assert client.get("/appointments/me", headers=patient, params={"when": "past"}).json()["total"] == 1


def test_17_doctor_views_appointments_for_a_day(client, doctor, patient):
    first, _ = make_slots(client, doctor)
    book(client, patient, first)
    day = client.get("/appointments/doctor", headers=doctor["headers"], params={"date": str(DAY)}).json()
    assert day["total"] == 1 and day["items"][0]["patient_name"] == "Patient One"
    assert client.get("/appointments/doctor", headers=doctor["headers"]).json()["total"] == 0  # today: none
    assert client.get("/appointments/doctor", headers=patient).status_code == 403


def test_18_doctor_marks_completed_or_no_show(client, doctor, patient, patient2):
    first, second = make_slots(client, doctor)
    one = book(client, patient, first).json()
    two = book(client, patient2, second).json()
    done = client.patch(f"/appointments/{one['id']}/status", headers=doctor["headers"], json={"status": "COMPLETED"})
    assert done.json()["status"] == "COMPLETED"
    missed = client.patch(f"/appointments/{two['id']}/status", headers=doctor["headers"], json={"status": "NO_SHOW"})
    assert missed.json()["status"] == "NO_SHOW"
    assert client.patch(f"/appointments/{one['id']}/status", headers=doctor["headers"], json={"status": "NO_SHOW"}).status_code == 409
    assert client.patch(f"/appointments/{one['id']}/status", headers=doctor["headers"], json={"status": "CANCELLED"}).status_code == 422


def test_19_doctor_records_a_consultation_for_a_completed_appointment(client, doctor, patient):
    first, _ = make_slots(client, doctor)
    appointment = book(client, patient, first).json()
    body = {"diagnosis": "Migraine", "prescription": "Rest", "notes": "Review soon", "follow_up_date": str(DAY)}
    url = f"/appointments/{appointment['id']}/consultation"
    assert client.post(url, headers=doctor["headers"], json=body).status_code == 409  # not COMPLETED yet
    client.patch(f"/appointments/{appointment['id']}/status", headers=doctor["headers"], json={"status": "COMPLETED"})
    recorded = client.post(url, headers=doctor["headers"], json=body)
    assert recorded.status_code == 201 and recorded.json()["doctor_name"] == "Dr. Test"
    assert client.post(url, headers=doctor["headers"], json=body).status_code == 409  # only once
    assert client.post(url, headers=patient, json=body).status_code == 403
    past = {**body, "follow_up_date": str(date.today() - timedelta(days=1))}
    assert client.post(url, headers=doctor["headers"], json=past).status_code == 422


def test_20_patient_views_consultation_history(client, doctor, patient, patient2):
    first, second = make_slots(client, doctor)
    appointment = book(client, patient, first).json()
    client.patch(f"/appointments/{appointment['id']}/status", headers=doctor["headers"], json={"status": "COMPLETED"})
    client.post(f"/appointments/{appointment['id']}/consultation", headers=doctor["headers"],
                json={"diagnosis": "Cold", "prescription": "Fluids", "follow_up_date": str(DAY)})
    history = client.get("/consultations/me", headers=patient).json()
    assert history["total"] == 1
    item = history["items"][0]
    assert (item["diagnosis"], item["prescription"], item["doctor_name"], item["follow_up_date"]) == ("Cold", "Fluids", "Dr. Test", str(DAY))
    assert client.get("/consultations/me", headers=patient2).json()["total"] == 0  # others see nothing


# ------------------------------------------------------------------------ gateway
def test_gateway_hides_internal_endpoints_and_ignores_forged_headers(client, patient):
    assert client.get("/internal/users/1", headers=patient).status_code == 404
    forged = {**patient, "x-user-role": "ADMIN", "x-user-id": "1"}
    assert client.patch("/users/1/deactivate", headers=forged).status_code == 403
    assert client.get("/patients/me", headers={"x-user-id": "1", "x-user-role": "PATIENT"}).status_code == 401


def test_swagger_shows_every_service(client):
    paths = client.get("/openapi.json").json()["paths"]
    for path in ["/auth/login", "/specialities", "/doctors", "/doctors/me", "/doctors/me/availability",
                 "/doctors/{doctor_id}/slots", "/slots/{slot_id}/block", "/patients/me", "/appointments",
                 "/appointments/{appointment_id}/consultation", "/consultations/me"]:
        assert path in paths
    assert not any(p.startswith("/internal") for p in paths)
