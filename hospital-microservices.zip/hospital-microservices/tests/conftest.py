import os
import tempfile

# One SQLite file per microservice, set before anything is imported
_tmp = tempfile.mkdtemp(prefix="hospital-tests-")
for name in ("AUTH", "DOCTOR", "PATIENT", "SCHEDULE", "APPOINTMENT"):
    os.environ[f"{name}_DATABASE_URL"] = f"sqlite:///{_tmp}/{name.lower()}.db"
os.environ["JWT_SECRET_KEY"] = "test-secret"
os.environ["INTERNAL_API_KEY"] = "test-internal-key"
os.environ["BCRYPT_ROUNDS"] = "4"

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from gateway.main import app  # noqa: E402
from services.appointment_service.app import database as appointment_db  # noqa: E402
from services.auth_service.app import database as auth_db  # noqa: E402
from services.auth_service.app.repositories import user_repo  # noqa: E402
from services.doctor_service.app import database as doctor_db  # noqa: E402
from services.patient_service.app import database as patient_db  # noqa: E402
from services.schedule_service.app import database as schedule_db  # noqa: E402
from shared.enums import Role  # noqa: E402
from shared.rate_limit import login_limiter  # noqa: E402
from shared.security import hash_password  # noqa: E402

DATABASES = [auth_db, doctor_db, patient_db, schedule_db, appointment_db]


@pytest.fixture(scope="session", autouse=True)
def create_tables():
    for database in DATABASES:
        database.Base.metadata.create_all(database.engine)


@pytest.fixture(autouse=True)
def empty_tables():
    login_limiter.reset()  # failed-login counters live in memory
    for database in DATABASES:
        with database.SessionLocal() as db:
            for table in reversed(database.Base.metadata.sorted_tables):
                db.execute(table.delete())
            db.commit()


@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c


def login(client, email, password) -> dict:
    response = client.post("/auth/login", data={"username": email, "password": password})
    assert response.status_code == 200, response.text
    return {"Authorization": f"Bearer {response.json()['access_token']}"}


@pytest.fixture
def admin(client):
    with auth_db.SessionLocal() as db:
        user_repo.create(db, "admin@test.com", hash_password("Admin123"), "Admin User", None, Role.ADMIN.value)
        db.commit()
    return login(client, "admin@test.com", "Admin123")


@pytest.fixture
def speciality(client, admin):
    return client.post("/specialities", json={"name": "Cardiology"}, headers=admin).json()


@pytest.fixture
def doctor(client, admin, speciality):
    """A doctor account created by the admin, already logged in."""
    response = client.post("/doctors", headers=admin, json={
        "email": "doctor@test.com", "password": "Password123", "full_name": "Dr. Test",
        "speciality_id": speciality["id"], "registration_no": "REG-001", "qualification": "MD",
        "experience_years": 10, "consultation_fee": "500.00"})
    assert response.status_code == 201, response.text
    return {"id": response.json()["id"], "headers": login(client, "doctor@test.com", "Password123")}


@pytest.fixture
def patient(client):
    """A patient who registered and logged in."""
    assert client.post("/auth/register", json={"email": "patient@test.com", "password": "Password123",
                                               "full_name": "Patient One", "phone": "7777777777"}).status_code == 201
    return login(client, "patient@test.com", "Password123")


@pytest.fixture
def patient2(client):
    client.post("/auth/register", json={"email": "patient2@test.com", "password": "Password123",
                                        "full_name": "Patient Two"})
    return login(client, "patient2@test.com", "Password123")
