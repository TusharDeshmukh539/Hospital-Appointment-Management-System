"""Tests for the features added on top of the 20 user stories (all through the API gateway)."""
from fastapi.testclient import TestClient

from services.auth_service.main import app as auth_app
from tests.conftest import login
from tests.test_user_stories import DAY, book, make_slots, slot_status


def audit_actions(client, admin, **params):
    return [e["action"] for e in client.get("/audit-logs", headers=admin, params={"size": 100, **params}).json()["items"]]


# ------------------------------------------------------------ admin patient list
def test_admin_lists_patients_with_search_and_sorting(client, admin, patient, patient2):
    everyone = client.get("/patients", headers=admin).json()
    assert everyone["total"] == 2
    assert [p["full_name"] for p in everyone["items"]] == ["Patient One", "Patient Two"]  # default: by name
    newest = client.get("/patients", headers=admin, params={"sort_by": "full_name", "order": "desc"}).json()
    assert newest["items"][0]["full_name"] == "Patient Two"
    found = client.get("/patients", headers=admin, params={"q": "patient2@"}).json()
    assert [p["email"] for p in found["items"]] == ["patient2@test.com"]
    assert client.get("/patients", headers=patient).status_code == 403  # patients cannot see other patients
    assert client.get("/patients", headers=admin, params={"sort_by": "password"}).status_code == 422


# ------------------------------------------------------------------ admin reports
def test_admin_report_counts_appointments_per_status_and_doctor(client, admin, doctor, patient, patient2):
    first, second = make_slots(client, doctor)
    a1 = book(client, patient, first).json()["id"]
    book(client, patient2, second)
    client.patch(f"/appointments/{a1}/status", headers=doctor["headers"], json={"status": "COMPLETED"})

    report = client.get("/admin/reports/appointments", headers=admin).json()
    assert report["total"] == 2
    assert report["by_status"] == {"BOOKED": 1, "COMPLETED": 1, "CANCELLED": 0, "NO_SHOW": 0}
    assert len(report["by_doctor"]) == 1
    row = report["by_doctor"][0]
    assert (row["doctor_name"], row["total"], row["COMPLETED"], row["BOOKED"]) == ("Dr. Test", 2, 1, 1)

    other_days = client.get("/admin/reports/appointments", headers=admin,
                            params={"from_date": str(DAY.replace(year=DAY.year + 1))}).json()
    assert other_days["total"] == 0 and other_days["by_doctor"] == []
    assert client.get("/admin/reports/appointments", headers=admin,
                      params={"from_date": "2030-02-01", "to_date": "2030-01-01"}).status_code == 400
    assert client.get("/admin/reports/appointments", headers=doctor["headers"]).status_code == 403


# ------------------------------------------------- unblock slot / delete availability
def test_doctor_unblocks_a_slot(client, doctor, patient):
    first, second = make_slots(client, doctor)
    assert client.patch(f"/slots/{first}/block", headers=doctor["headers"]).status_code == 200
    assert client.patch(f"/slots/{first}/unblock", headers=doctor["headers"]).json()["status"] == "FREE"
    assert client.patch(f"/slots/{first}/unblock", headers=doctor["headers"]).status_code == 409  # not blocked now
    assert book(client, patient, second).status_code == 201
    assert client.patch(f"/slots/{second}/unblock", headers=doctor["headers"]).status_code == 409  # BOOKED
    assert slot_status(second) == "BOOKED"
    assert client.patch(f"/slots/{first}/unblock", headers=patient).status_code == 403


def test_doctor_deletes_an_availability_window(client, doctor):
    window = client.post("/doctors/me/availability", headers=doctor["headers"], json={
        "weekday": 0, "start_time": "09:00:00", "end_time": "12:00:00"}).json()
    assert client.delete(f"/doctors/me/availability/{window['id']}", headers=doctor["headers"]).status_code == 204
    assert client.get("/doctors/me/availability", headers=doctor["headers"]).json() == []
    assert client.delete(f"/doctors/me/availability/{window['id']}", headers=doctor["headers"]).status_code == 404


def test_a_doctor_cannot_delete_another_doctors_availability(client, admin, doctor, speciality):
    window = client.post("/doctors/me/availability", headers=doctor["headers"], json={
        "weekday": 0, "start_time": "09:00:00", "end_time": "12:00:00"}).json()
    client.post("/doctors", headers=admin, json={
        "email": "doc2@test.com", "password": "Password123", "full_name": "Dr. Two", "speciality_id": speciality["id"],
        "registration_no": "REG-002", "qualification": "MD", "experience_years": 3, "consultation_fee": "100"})
    other = login(client, "doc2@test.com", "Password123")
    assert client.delete(f"/doctors/me/availability/{window['id']}", headers=other).status_code == 404
    assert len(client.get("/doctors/me/availability", headers=doctor["headers"]).json()) == 1


# ------------------------------------------------------------------- activate user
def test_admin_reactivates_a_user(client, admin, doctor, patient):
    from services.auth_service.app.database import SessionLocal
    from services.auth_service.app.models import User
    with SessionLocal() as db:
        doctor_user = db.query(User).filter(User.email == "doctor@test.com").one().id
    assert client.patch(f"/users/{doctor_user}/deactivate", headers=admin).status_code == 200
    assert client.post("/auth/login", data={"username": "doctor@test.com", "password": "Password123"}).status_code == 403
    assert client.get("/doctors", headers=patient).json()["total"] == 0

    activated = client.patch(f"/users/{doctor_user}/activate", headers=admin)
    assert activated.status_code == 200 and activated.json()["is_active"] is True
    assert client.post("/auth/login", data={"username": "doctor@test.com", "password": "Password123"}).status_code == 200
    assert client.get("/doctors", headers=patient).json()["total"] == 1  # visible in searches again
    assert client.patch(f"/users/{doctor_user}/activate", headers=patient).status_code == 403
    assert client.patch("/users/9999/activate", headers=admin).status_code == 404


# ------------------------------------------------- single doctor / single consultation
def test_view_one_doctor(client, admin, doctor, patient):
    view = client.get(f"/doctors/{doctor['id']}", headers=patient)
    assert view.status_code == 200
    assert (view.json()["full_name"], view.json()["speciality_name"]) == ("Dr. Test", "Cardiology")
    assert client.get("/doctors/9999", headers=patient).status_code == 404
    assert client.get("/doctors/me", headers=doctor["headers"]).status_code == 200  # /me still works


def test_a_deactivated_doctor_is_hidden_from_everyone_but_admins(client, admin, doctor, patient):
    from services.auth_service.app.database import SessionLocal
    from services.auth_service.app.models import User
    with SessionLocal() as db:
        doctor_user = db.query(User).filter(User.email == "doctor@test.com").one().id
    client.patch(f"/users/{doctor_user}/deactivate", headers=admin)
    assert client.get(f"/doctors/{doctor['id']}", headers=patient).status_code == 404
    assert client.get(f"/doctors/{doctor['id']}", headers=admin).status_code == 200


def test_view_one_consultation(client, doctor, patient, patient2, admin):
    first, _ = make_slots(client, doctor)
    appointment_id = book(client, patient, first).json()["id"]
    client.patch(f"/appointments/{appointment_id}/status", headers=doctor["headers"], json={"status": "COMPLETED"})
    created = client.post(f"/appointments/{appointment_id}/consultation", headers=doctor["headers"],
                          json={"diagnosis": "Cold", "prescription": "Fluids"}).json()

    mine = client.get(f"/consultations/{created['id']}", headers=patient)
    assert mine.status_code == 200 and mine.json()["diagnosis"] == "Cold"
    assert client.get(f"/consultations/{created['id']}", headers=doctor["headers"]).status_code == 200
    assert client.get(f"/consultations/{created['id']}", headers=patient2).status_code == 404  # not theirs
    assert client.get(f"/consultations/{created['id']}", headers=admin).status_code == 403  # medical data
    assert client.get("/consultations/9999", headers=patient).status_code == 404
    assert client.get("/consultations/me", headers=patient).json()["total"] == 1  # /me still works


# ----------------------------------------------------------------- login rate limit
def test_login_is_rate_limited_after_too_many_wrong_passwords(client, patient):
    wrong = {"username": "patient@test.com", "password": "Wrong12345"}
    for _ in range(5):
        assert client.post("/auth/login", data=wrong).status_code == 401
    blocked = client.post("/auth/login", data=wrong)
    assert blocked.status_code == 429 and "Try again" in blocked.json()["detail"]
    # even the right password is refused while the limit is active, but other accounts are not affected
    assert client.post("/auth/login", data={"username": "patient@test.com", "password": "Password123"}).status_code == 429
    client.post("/auth/register", json={"email": "other@test.com", "password": "Password123", "full_name": "Other"})
    assert client.post("/auth/login", data={"username": "other@test.com", "password": "Password123"}).status_code == 200


def test_a_successful_login_resets_the_failed_attempts(client, patient):
    for _ in range(4):
        client.post("/auth/login", data={"username": "patient@test.com", "password": "Wrong12345"})
    assert client.post("/auth/login", data={"username": "patient@test.com", "password": "Password123"}).status_code == 200
    for _ in range(4):
        assert client.post("/auth/login", data={"username": "patient@test.com", "password": "Wrong12345"}).status_code == 401


# ------------------------------------------------------------------- audit logging
def test_important_actions_are_audited_and_only_admins_can_read_them(client, admin, doctor, patient):
    first, _ = make_slots(client, doctor)
    appointment_id = book(client, patient, first).json()["id"]
    client.patch(f"/appointments/{appointment_id}/cancel", headers=patient)
    client.post("/auth/login", data={"username": "patient@test.com", "password": "Wrong12345"})

    actions = audit_actions(client, admin)
    for expected in ["USER_REGISTERED", "LOGIN_SUCCESS", "LOGIN_FAILED", "SPECIALITY_CREATED", "DOCTOR_CREATED",
                     "AVAILABILITY_ADDED", "SLOTS_GENERATED", "APPOINTMENT_BOOKED", "APPOINTMENT_CANCELLED"]:
        assert expected in actions, expected
    booked = client.get("/audit-logs", headers=admin, params={"action": "appointment_booked"}).json()
    assert booked["total"] == 1 and booked["items"][0]["entity_id"] == appointment_id
    assert booked["items"][0]["user_id"] is not None and booked["items"][0]["created_at"]

    assert client.get("/audit-logs", headers=patient).status_code == 403
    assert client.post("/internal/audit", json={"action": "X"}).status_code == 404  # not reachable from outside


def test_admin_actions_and_rate_limiting_are_audited(client, admin, patient):
    from services.auth_service.app.database import SessionLocal
    from services.auth_service.app.models import User
    with SessionLocal() as db:
        patient_user = db.query(User).filter(User.email == "patient@test.com").one().id
    client.patch(f"/users/{patient_user}/deactivate", headers=admin)
    client.patch(f"/users/{patient_user}/activate", headers=admin)
    for _ in range(6):
        client.post("/auth/login", data={"username": "nobody@test.com", "password": "Wrong12345"})
    actions = audit_actions(client, admin)
    assert {"USER_DEACTIVATED", "USER_ACTIVATED", "LOGIN_RATE_LIMITED"} <= set(actions)
    # newest first by default, and the order can be reversed
    first = client.get("/audit-logs", headers=admin, params={"order": "asc"}).json()["items"][0]["id"]
    last = client.get("/audit-logs", headers=admin).json()["items"][0]["id"]
    assert first < last


def test_a_broken_audit_trail_never_breaks_the_real_action(client, admin, monkeypatch):
    from shared import audit

    def broken(*args, **kwargs):
        raise RuntimeError("auth service down")

    monkeypatch.setattr(audit, "call", broken)
    assert client.post("/specialities", json={"name": "Neurology"}, headers=admin).status_code == 201


# ------------------------------------------------------------------------ internal key
def test_internal_endpoints_need_the_internal_key():
    direct = TestClient(auth_app)  # the service itself, bypassing the gateway
    assert direct.get("/internal/users/1").status_code == 403
    assert direct.get("/internal/users/1", headers={"x-internal-key": "wrong"}).status_code == 403
    assert direct.get("/internal/users/1", headers={"x-internal-key": "test-internal-key"}).status_code == 404


# ------------------------------------------------------------------------- timestamps
def test_records_carry_created_at_and_updated_at(client, admin, doctor, patient):
    profile = client.get("/patients/me", headers=patient).json()
    assert profile["created_at"] and profile["updated_at"]
    updated = client.put("/patients/me", headers=patient, json={"address": "Somewhere 1"}).json()
    assert updated["created_at"] == profile["created_at"]
    assert updated["updated_at"] > profile["updated_at"]

    first, _ = make_slots(client, doctor)
    slot = client.get("/doctors/me/slots", headers=doctor["headers"], params={"date": str(DAY)}).json()[0]
    assert slot["created_at"] and slot["updated_at"]
    blocked = client.patch(f"/slots/{first}/block", headers=doctor["headers"]).json()
    assert blocked["updated_at"] > slot["updated_at"]  # status changes bump updated_at

    assert client.get(f"/doctors/{doctor['id']}", headers=patient).json()["created_at"]
    assert client.get("/specialities", headers=patient).json()["items"][0]["created_at"]


# ---------------------------------------------------------------------------- sorting
def test_doctors_can_be_sorted(client, admin, doctor, speciality, patient):
    client.post("/doctors", headers=admin, json={
        "email": "doc2@test.com", "password": "Password123", "full_name": "Dr. Adams", "speciality_id": speciality["id"],
        "registration_no": "REG-002", "qualification": "MD", "experience_years": 25, "consultation_fee": "100"})

    def names(**params):
        return [d["full_name"] for d in client.get("/doctors", headers=patient, params=params).json()["items"]]

    assert names() == ["Dr. Adams", "Dr. Test"]  # default unchanged: by name
    assert names(sort_by="full_name", order="desc") == ["Dr. Test", "Dr. Adams"]
    assert names(sort_by="consultation_fee") == ["Dr. Adams", "Dr. Test"]
    assert names(sort_by="consultation_fee", order="desc") == ["Dr. Test", "Dr. Adams"]
    assert names(sort_by="experience_years", order="desc") == ["Dr. Adams", "Dr. Test"]
    assert client.get("/doctors", headers=patient, params={"sort_by": "bogus"}).status_code == 422
    assert client.get("/doctors", headers=patient, params={"order": "sideways"}).status_code == 422


def test_specialities_and_appointments_can_be_sorted(client, admin, doctor, patient):
    client.post("/specialities", json={"name": "Allergy"}, headers=admin)
    listed = client.get("/specialities", headers=admin, params={"sort_by": "name", "order": "desc"}).json()["items"]
    assert [s["name"] for s in listed] == ["Cardiology", "Allergy"]

    first, second = make_slots(client, doctor)
    book(client, patient, first)
    mine = client.get("/appointments/me", headers=patient, params={"order": "desc"}).json()["items"]
    assert len(mine) == 1
    day_view = client.get("/appointments/doctor", headers=doctor["headers"],
                          params={"date": str(DAY), "sort_by": "patient_name", "order": "desc"})
    assert day_view.status_code == 200 and day_view.json()["total"] == 1
    assert client.get("/appointments/me", headers=patient, params={"sort_by": "reason"}).status_code == 422


def test_consultations_can_be_sorted(client, doctor, patient):
    first, _ = make_slots(client, doctor)
    appointment_id = book(client, patient, first).json()["id"]
    client.patch(f"/appointments/{appointment_id}/status", headers=doctor["headers"], json={"status": "COMPLETED"})
    client.post(f"/appointments/{appointment_id}/consultation", headers=doctor["headers"],
                json={"diagnosis": "Cold", "prescription": "Fluids"})
    for params in ({}, {"order": "asc"}, {"sort_by": "id", "order": "desc"}):
        assert client.get("/consultations/me", headers=patient, params=params).json()["total"] == 1


def test_swagger_shows_the_new_endpoints(client):
    paths = client.get("/openapi.json").json()["paths"]
    for path in ["/patients", "/admin/reports/appointments", "/slots/{slot_id}/unblock",
                 "/doctors/me/availability/{availability_id}", "/users/{user_id}/activate",
                 "/doctors/{doctor_id}", "/consultations/{consultation_id}", "/audit-logs"]:
        assert path in paths, path
    assert not any(p.startswith("/internal") for p in paths)
